-- MySQL dump 10.13  Distrib 5.1.54, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: b2b
-- ------------------------------------------------------
-- Server version	5.1.54-1ubuntu4-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `adminfields`
--

DROP TABLE IF EXISTS `adminfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adminfields` (
  `member_id` int(10) NOT NULL DEFAULT '0',
  `depart_id` tinyint(1) NOT NULL DEFAULT '0',
  `first_name` varchar(25) NOT NULL DEFAULT '',
  `last_name` varchar(25) NOT NULL DEFAULT '',
  `level` tinyint(1) NOT NULL DEFAULT '0',
  `last_login` int(10) NOT NULL DEFAULT '0',
  `last_ip` varchar(25) NOT NULL DEFAULT '',
  `expired` int(10) NOT NULL DEFAULT '0',
  `permissions` text NOT NULL,
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`member_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adminfields`
--

LOCK TABLES `adminfields` WRITE;
/*!40000 ALTER TABLE `adminfields` DISABLE KEYS */;
INSERT INTO `adminfields` VALUES (1,0,'','administrator',0,0,'',0,'',1313811281,1313811281);
/*!40000 ALTER TABLE `adminfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `adminmodules`
--

DROP TABLE IF EXISTS `adminmodules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adminmodules` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `parent_id` smallint(3) NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adminmodules`
--

LOCK TABLES `adminmodules` WRITE;
/*!40000 ALTER TABLE `adminmodules` DISABLE KEYS */;
/*!40000 ALTER TABLE `adminmodules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `adminnotes`
--

DROP TABLE IF EXISTS `adminnotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adminnotes` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `member_id` int(10) NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `content` text,
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adminnotes`
--

LOCK TABLES `adminnotes` WRITE;
/*!40000 ALTER TABLE `adminnotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `adminnotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `adminprivileges`
--

DROP TABLE IF EXISTS `adminprivileges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adminprivileges` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `adminmodule_id` int(5) NOT NULL DEFAULT '0',
  `name` varchar(25) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adminprivileges`
--

LOCK TABLES `adminprivileges` WRITE;
/*!40000 ALTER TABLE `adminprivileges` DISABLE KEYS */;
/*!40000 ALTER TABLE `adminprivileges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `adminroles`
--

DROP TABLE IF EXISTS `adminroles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adminroles` (
  `id` tinyint(2) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adminroles`
--

LOCK TABLES `adminroles` WRITE;
/*!40000 ALTER TABLE `adminroles` DISABLE KEYS */;
/*!40000 ALTER TABLE `adminroles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `adses`
--

DROP TABLE IF EXISTS `adses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adses` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `adzone_id` smallint(3) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL DEFAULT '',
  `description` text,
  `is_image` tinyint(1) NOT NULL DEFAULT '1',
  `source_name` varchar(100) NOT NULL DEFAULT '',
  `source_type` varchar(100) NOT NULL DEFAULT '',
  `source_url` varchar(255) NOT NULL DEFAULT '',
  `target_url` varchar(255) NOT NULL DEFAULT '',
  `width` smallint(6) NOT NULL DEFAULT '0',
  `height` smallint(6) NOT NULL DEFAULT '0',
  `alt_words` varchar(25) NOT NULL DEFAULT '',
  `start_date` int(10) NOT NULL DEFAULT '0',
  `end_date` int(10) NOT NULL DEFAULT '0',
  `priority` tinyint(1) NOT NULL DEFAULT '0',
  `clicked` smallint(6) NOT NULL DEFAULT '1',
  `target` enum('_parent','_self','_blank') NOT NULL DEFAULT '_blank',
  `seq` tinyint(1) NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `picture_replace` varchar(255) NOT NULL DEFAULT '',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adses`
--

LOCK TABLES `adses` WRITE;
/*!40000 ALTER TABLE `adses` DISABLE KEYS */;
INSERT INTO `adses` VALUES (1,1,'GIF','Sample Ad 1',1,'','image/gif','attachment/sample/default/blue.gif','',152,52,'',0,0,0,1,'_blank',0,1,1,'',1313811282,1313811282),(2,1,'JPG','Sample Ad 2',1,'','image/gif','attachment/sample/default/blue.gif','',152,52,'',0,0,0,1,'_blank',0,1,1,'',1313811282,1313811282),(3,1,'PNG','Sample Ad 3',1,'','image/gif','attachment/sample/default/blue.gif','',152,52,'',0,0,0,1,'_blank',0,1,1,'',1313811282,1313811282),(4,1,'Sample Ad 4','',1,'','image/gif','attachment/sample/default/blue.gif','',152,52,'',0,0,0,1,'_blank',0,1,1,'',1313811282,1313811282),(5,1,'Sample Ad 5','PNG',1,'','image/gif','attachment/sample/default/blue.gif','',152,52,'',0,0,0,1,'_blank',0,1,1,'',1313811282,1313811282),(6,1,'Sample Ad 6','',1,'','image/gif','attachment/sample/default/blue.gif','',152,52,'',0,0,0,1,'_blank',0,1,1,'',1313811282,1313811282),(7,2,'Sample Ad','',1,'','image/pjpeg','attachment/sample/example_958.jpg','http://www.phpb2b.com',958,62,'',0,0,0,1,'_blank',0,1,1,'attachment/sample/example_958.jpg',1313811282,1313811282),(8,3,'Trade AD','',1,'','image/pjpeg','attachment/sample/breathe-offer1.jpg','',477,170,'',0,0,0,1,'_blank',0,1,1,'images/nopicture_small.gif',1313811282,1313811282),(9,3,'Welcome Register','Register',1,'','image/pjpeg','attachment/sample/breathe-offer2.jpg','',477,170,'',0,0,0,1,'_blank',0,1,1,'images/nopicture_small.gif',1313811282,1313811282),(15,4,'','',1,'','image/pjpeg','attachment/sample/breathe-product1.jpg','',500,200,'',0,0,0,1,'_blank',0,1,1,'images/nopicture_small.gif',1313811282,1303735837),(16,5,'','',1,'','image/pjpeg','attachment/sample/breathe-index1.jpg','',500,200,'',0,0,0,1,'_blank',0,1,1,'images/nopicture_small.gif',1313811282,1313811282),(18,4,'','',1,'','image/pjpeg','attachment/sample/breathe-product2.jpg','',570,170,'',0,0,0,1,'_blank',0,1,1,'images/nopicture_small.gif',1313811282,1313811282),(17,5,'','asdf',1,'','image/pjpeg','attachment/sample/breathe-index2.jpg','',500,200,'',0,0,0,1,'_blank',0,1,1,'images/nopicture_small.gif',1313811282,1313811282),(19,6,'ר','ʾ',1,'','image/pjpeg','attachment/sample/144x120.png','http://www.phpb2b.com/',500,200,'',0,0,0,1,'_blank',0,1,1,'images/nopicture_small.gif',1313811282,1313811282),(20,6,'ר',NULL,1,'','image/pjpeg','attachment/sample/144x120.png','http://www.phpb2b.com/',500,200,'',0,0,0,1,'_blank',0,1,1,'images/nopicture_small.gif',1313811282,1313811282),(21,6,'ר',NULL,1,'','image/pjpeg','attachment/sample/144x120.png','http://www.phpb2b.com/',500,200,'',0,0,0,1,'_blank',0,1,1,'images/nopicture_small.gif',1313811282,1313811282),(24,7,'','',1,'','image/pjpeg','attachment/sample/phpb2b.jpg','http://bbs.phpb2b.com/',220,82,'',0,0,0,1,'_blank',0,1,1,'images/nopicture_small.gif',1313811282,1313811282);
/*!40000 ALTER TABLE `adses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `adzones`
--

DROP TABLE IF EXISTS `adzones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adzones` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `membergroup_ids` varchar(50) NOT NULL DEFAULT '',
  `what` varchar(10) NOT NULL DEFAULT '',
  `style` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL DEFAULT '',
  `description` text,
  `additional_adwords` text,
  `price` float(9,2) NOT NULL DEFAULT '0.00',
  `file_name` varchar(100) NOT NULL DEFAULT '',
  `width` smallint(6) NOT NULL DEFAULT '0',
  `height` smallint(6) NOT NULL DEFAULT '0',
  `wrap` smallint(6) NOT NULL DEFAULT '0',
  `max_ad` smallint(6) NOT NULL DEFAULT '0',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adzones`
--

LOCK TABLES `adzones` WRITE;
/*!40000 ALTER TABLE `adzones` DISABLE KEYS */;
INSERT INTO `adzones` VALUES (1,'8,9','1',0,'','6','',1000.00,'index.php',760,52,6,12,1313811282,1313811282),(2,'0','1',0,'','','',3000.00,'index.php',958,62,0,0,1313811282,1313811282),(3,'','1',1,'','','',1000.00,'',380,270,0,0,1313811282,1313811282),(4,'','1',1,'','6','',0.01,'',570,170,0,0,1313811282,1313811282),(5,'0','1',1,'','','',0.01,'',473,170,0,0,1313811282,1313811282),(6,'','1',0,'ר','','',0.00,'',0,0,0,0,1313811282,1313811282),(7,'','1',0,'Community','PHPB2B community','',0.00,'',0,0,0,0,1313811282,1313811282);
/*!40000 ALTER TABLE `adzones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `albums`
--

DROP TABLE IF EXISTS `albums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `albums` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `member_id` int(10) NOT NULL DEFAULT '0',
  `attachment_id` int(10) NOT NULL DEFAULT '0',
  `type_id` smallint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `albums`
--

LOCK TABLES `albums` WRITE;
/*!40000 ALTER TABLE `albums` DISABLE KEYS */;
/*!40000 ALTER TABLE `albums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `albumtypes`
--

DROP TABLE IF EXISTS `albumtypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `albumtypes` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `display_order` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `albumtypes`
--

LOCK TABLES `albumtypes` WRITE;
/*!40000 ALTER TABLE `albumtypes` DISABLE KEYS */;
INSERT INTO `albumtypes` VALUES (1,'Albums',0),(2,'Products',0),(3,'Advertisement',0);
/*!40000 ALTER TABLE `albumtypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcements` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `announcetype_id` smallint(3) NOT NULL DEFAULT '0',
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` text,
  `display_order` tinyint(1) NOT NULL DEFAULT '0',
  `display_expiration` int(10) unsigned NOT NULL DEFAULT '0',
  `created` int(10) unsigned NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
INSERT INTO `announcements` VALUES (4,1,'How to build your shop',NULL,0,0,1313811282,0),(3,2,'Service Introduction',NULL,0,0,1313811282,0),(2,1,'Upload your company info',NULL,0,0,1313811282,0),(1,1,'The world expo ','Shanghai world expo',0,0,1313811282,0);
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcementtypes`
--

DROP TABLE IF EXISTS `announcementtypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcementtypes` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcementtypes`
--

LOCK TABLES `announcementtypes` WRITE;
/*!40000 ALTER TABLE `announcementtypes` DISABLE KEYS */;
INSERT INTO `announcementtypes` VALUES (1,'Site Announce'),(2,'Site Ads');
/*!40000 ALTER TABLE `announcementtypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `areas`
--

DROP TABLE IF EXISTS `areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `areas` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `attachment_id` int(10) NOT NULL DEFAULT '0',
  `areatype_id` smallint(3) NOT NULL DEFAULT '0',
  `child_ids` text,
  `top_parentid` smallint(6) NOT NULL DEFAULT '0',
  `level` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `alias_name` varchar(255) NOT NULL DEFAULT '',
  `highlight` tinyint(1) NOT NULL DEFAULT '0',
  `parent_id` smallint(6) NOT NULL DEFAULT '0',
  `display_order` tinyint(1) NOT NULL DEFAULT '0',
  `description` text,
  `available` tinyint(1) NOT NULL DEFAULT '1',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `areas`
--

LOCK TABLES `areas` WRITE;
/*!40000 ALTER TABLE `areas` DISABLE KEYS */;
INSERT INTO `areas` VALUES (1,0,0,NULL,0,1,'Australia','','',0,0,0,NULL,1,0,0),(2,0,0,NULL,0,1,'Indonesia','','',0,0,0,NULL,1,0,0),(3,0,0,NULL,0,1,'New Zealand','','',0,0,0,NULL,1,0,0),(4,0,0,NULL,0,1,'South Korea','','',0,0,0,NULL,1,0,0),(5,0,0,NULL,0,1,'China','','',0,0,0,NULL,1,0,0),(6,0,0,NULL,0,1,'Iran','','',0,0,0,NULL,1,0,0),(7,0,0,NULL,0,1,'Pakistan','','',0,0,0,NULL,1,0,0),(8,0,0,NULL,0,1,'Taiwan','','',0,0,0,NULL,1,0,0),(9,0,0,NULL,0,1,'Hong Kong','','',0,0,0,NULL,1,0,0),(10,0,0,NULL,0,1,'Japan','','',0,0,0,NULL,1,0,0),(11,0,0,NULL,0,1,'Philippines','','',0,0,0,NULL,1,0,0),(12,0,0,NULL,0,1,'Thailand','','',0,0,0,NULL,1,0,0),(13,0,0,NULL,0,1,'India','','',0,0,0,NULL,1,0,0),(14,0,0,NULL,0,1,'Malaysia','','',0,0,0,NULL,1,0,0),(15,0,0,NULL,0,1,'Singapore','','',0,0,0,NULL,1,0,0),(16,0,0,NULL,0,1,'Vietnam','','',0,0,0,NULL,1,0,0),(17,0,0,NULL,0,1,'Argentina','','',0,0,0,NULL,1,0,0),(18,0,0,NULL,0,1,'Canada','','',0,0,0,NULL,1,0,0),(19,0,0,NULL,0,1,'Colombia','','',0,0,0,NULL,1,0,0),(20,0,0,NULL,0,1,'Peru','','',0,0,0,NULL,1,0,0),(21,0,0,NULL,0,1,'Brazil','','',0,0,0,NULL,1,0,0),(22,0,0,NULL,0,1,'Chile','','',0,0,0,NULL,1,0,0),(23,0,0,NULL,0,1,'Mexico','','',0,0,0,NULL,1,0,0),(24,0,0,NULL,0,1,'United States','','',0,0,0,NULL,1,0,0),(25,0,0,NULL,0,1,'Belgium','','',0,0,0,NULL,1,0,0),(26,0,0,NULL,0,1,'Germany','','',0,0,0,NULL,1,0,0),(27,0,0,NULL,0,1,'Poland','','',0,0,0,NULL,1,0,0),(28,0,0,NULL,0,1,'Sweden','','',0,0,0,NULL,1,0,0),(29,0,0,NULL,0,1,'Bulgaria','','',0,0,0,NULL,1,0,0),(30,0,0,NULL,0,1,'Greece','','',0,0,0,NULL,1,0,0),(31,0,0,NULL,0,1,'Portugal','','',0,0,0,NULL,1,0,0),(32,0,0,NULL,0,1,'Switzerland','','',0,0,0,NULL,1,0,0),(33,0,0,NULL,0,1,'Czech Republic','','',0,0,0,NULL,1,0,0),(34,0,0,NULL,0,1,'Iceland','','',0,0,0,NULL,1,0,0),(35,0,0,NULL,0,1,'Romania','','',0,0,0,NULL,1,0,0),(36,0,0,NULL,0,1,'Turkey','','',0,0,0,NULL,1,0,0),(37,0,0,NULL,0,1,'Denmark','','',0,0,0,NULL,1,0,0),(38,0,0,NULL,0,1,'Italy','','',0,0,0,NULL,1,0,0),(39,0,0,NULL,0,1,'Russia','','',0,0,0,NULL,1,0,0),(40,0,0,NULL,0,1,'Ukraine','','',0,0,0,NULL,1,0,0),(41,0,0,NULL,0,1,'France','','',0,0,0,NULL,1,0,0),(42,0,0,NULL,0,1,'Netherlands','','',0,0,0,NULL,1,0,0),(43,0,0,NULL,0,1,'Spain','','',0,0,0,NULL,1,0,0),(44,0,0,NULL,0,1,'United Kingdom','','',0,0,0,NULL,1,0,0),(45,0,0,NULL,0,1,'Israel','','',0,0,0,NULL,1,0,0),(46,0,0,NULL,0,1,'Syria','','',0,0,0,NULL,1,0,0),(47,0,0,NULL,0,1,'United Arab ','','',0,0,0,NULL,1,0,0),(48,0,0,NULL,0,1,'Emirates','','',0,0,0,NULL,1,0,0),(49,0,0,NULL,0,1,'Saudi Arabia','','',0,0,0,NULL,1,0,0),(50,0,0,NULL,0,1,'Egypt','','',0,0,0,NULL,1,0,0),(51,0,0,NULL,0,1,'South Africa','','',0,0,0,NULL,1,0,0);
/*!40000 ALTER TABLE `areas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `areatypes`
--

DROP TABLE IF EXISTS `areatypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `areatypes` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `areatypes`
--

LOCK TABLES `areatypes` WRITE;
/*!40000 ALTER TABLE `areatypes` DISABLE KEYS */;
INSERT INTO `areatypes` VALUES (2,'Northeast'),(3,'East China'),(4,'Central China'),(5,'Southwest'),(6,'Northwest'),(7,'South China'),(8,'SAR');
/*!40000 ALTER TABLE `areatypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attachments`
--

DROP TABLE IF EXISTS `attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attachments` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `attachmenttype_id` smallint(3) NOT NULL DEFAULT '0',
  `member_id` int(10) NOT NULL DEFAULT '-1',
  `file_name` char(100) NOT NULL DEFAULT '',
  `attachment` char(255) NOT NULL DEFAULT '',
  `title` char(100) NOT NULL DEFAULT '',
  `description` text,
  `file_type` char(50) NOT NULL DEFAULT '0',
  `file_size` mediumint(8) NOT NULL DEFAULT '0',
  `thumb` varchar(100) NOT NULL DEFAULT '',
  `remote` varchar(100) NOT NULL DEFAULT '',
  `is_image` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachments`
--

LOCK TABLES `attachments` WRITE;
/*!40000 ALTER TABLE `attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attachmenttypes`
--

DROP TABLE IF EXISTS `attachmenttypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attachmenttypes` (
  `id` tinyint(1) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachmenttypes`
--

LOCK TABLES `attachmenttypes` WRITE;
/*!40000 ALTER TABLE `attachmenttypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `attachmenttypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banned`
--

DROP TABLE IF EXISTS `banned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banned` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `ip1` char(3) NOT NULL DEFAULT '',
  `ip2` char(3) NOT NULL DEFAULT '',
  `ip3` char(3) NOT NULL DEFAULT '',
  `ip4` char(3) NOT NULL DEFAULT '',
  `expiration` int(10) NOT NULL DEFAULT '0',
  `created` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip1` (`ip1`,`ip2`,`ip3`,`ip4`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banned`
--

LOCK TABLES `banned` WRITE;
/*!40000 ALTER TABLE `banned` DISABLE KEYS */;
/*!40000 ALTER TABLE `banned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brands` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `member_id` int(10) NOT NULL DEFAULT '-1',
  `company_id` int(10) NOT NULL DEFAULT '-1',
  `type_id` smallint(3) NOT NULL DEFAULT '0',
  `if_commend` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL DEFAULT '',
  `alias_name` varchar(100) NOT NULL DEFAULT '',
  `picture` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `hits` smallint(6) NOT NULL DEFAULT '0',
  `ranks` smallint(3) NOT NULL DEFAULT '0',
  `letter` varchar(2) NOT NULL DEFAULT '',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brands`
--

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` VALUES (1,-1,0,1,1,'palm','palm','sample/brand/1.jpg','',1,0,'p',1313811282,0),(2,-1,0,2,1,'LG','LG','sample/brand/2.jpg','',1,0,'l',1313811282,0),(3,-1,0,4,0,'Moto','motolola','sample/brand/3.jpg','',1,0,'m',1313811282,0),(4,-1,1,4,1,'Nokia','nokia','sample/brand/4.jpg','',1,0,'n',1313811282,0),(13,1,1,4,1,'Philips','philips','sample/brand/5.jpg','',0,0,'f',1313811282,0),(14,-1,1,4,0,'Samsung','samsung','sample/brand/6.jpg','',0,0,'s',1313811282,0),(7,-1,1,4,0,'Panasonic','panasonic','sample/brand/7.jpg','',0,0,'s',1313811282,0),(8,-1,1,4,0,'Sonic','sony','sample/brand/8.jpg','',0,0,'s',1313811282,0),(9,-1,1,3,0,'Semens','simens','sample/brand/9.jpg','',0,0,'x',1313811282,0),(10,1,1,2,0,'Nike','alcatel','sample/brand/10.jpg','asdf',0,0,'a',1313811282,0),(11,-1,1,0,0,'Adidas','Adidas','sample/brand/11.jpg','',0,0,'',0,0),(12,-1,1,0,0,'Suntory','','sample/brand/12.jpg','',0,0,'',0,0),(5,-1,1,0,0,'China Mobile','','sample/brand/13.jpg','',0,0,'',0,0),(6,-1,1,0,0,'CNNIC','','sample/brand/14.jpg','',0,0,'',0,0);
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brandtypes`
--

DROP TABLE IF EXISTS `brandtypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brandtypes` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `parent_id` smallint(3) NOT NULL DEFAULT '0',
  `level` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(100) NOT NULL DEFAULT '',
  `display_order` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brandtypes`
--

LOCK TABLES `brandtypes` WRITE;
/*!40000 ALTER TABLE `brandtypes` DISABLE KEYS */;
INSERT INTO `brandtypes` VALUES (1,0,1,'Regional',0),(2,0,1,'Domestic',0),(3,0,1,'International',0),(4,0,1,'Manufacturer',0),(5,0,1,'Operators',0),(6,0,1,'Own',0),(7,0,1,'Foreign',0),(8,0,1,'Grafting',0),(9,5,2,'Home appliances',0),(10,5,2,'Food beverage',0),(11,5,2,'Household chemicals',0),(12,5,2,'Services',0);
/*!40000 ALTER TABLE `brandtypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companies`
--

DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `companies` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `member_id` int(10) NOT NULL DEFAULT '0',
  `cache_spacename` varchar(255) NOT NULL DEFAULT '',
  `cache_membergroupid` smallint(3) NOT NULL DEFAULT '0',
  `cache_credits` smallint(6) NOT NULL DEFAULT '0',
  `topleveldomain` varchar(255) NOT NULL DEFAULT '',
  `industry_id` smallint(6) NOT NULL DEFAULT '0',
  `area_id` char(6) NOT NULL DEFAULT '0',
  `type_id` tinyint(2) NOT NULL DEFAULT '0',
  `name` char(255) NOT NULL DEFAULT '',
  `description` text,
  `english_name` char(100) NOT NULL DEFAULT '',
  `adwords` char(25) NOT NULL DEFAULT '',
  `keywords` varchar(50) NOT NULL DEFAULT '',
  `boss_name` varchar(25) NOT NULL DEFAULT '',
  `manage_type` varchar(25) NOT NULL DEFAULT '',
  `year_annual` tinyint(2) NOT NULL DEFAULT '0',
  `property` tinyint(1) NOT NULL DEFAULT '0',
  `configs` text,
  `bank_from` varchar(50) NOT NULL DEFAULT '',
  `bank_account` varchar(50) NOT NULL DEFAULT '',
  `main_prod` varchar(100) NOT NULL DEFAULT '',
  `employee_amount` varchar(25) NOT NULL DEFAULT '',
  `found_date` char(10) NOT NULL DEFAULT '0',
  `reg_fund` tinyint(2) NOT NULL DEFAULT '0',
  `reg_address` varchar(200) NOT NULL DEFAULT '',
  `address` varchar(200) NOT NULL DEFAULT '',
  `zipcode` varchar(15) NOT NULL DEFAULT '',
  `main_brand` varchar(100) NOT NULL DEFAULT '',
  `main_market` varchar(200) NOT NULL DEFAULT '',
  `main_biz_place` varchar(50) NOT NULL DEFAULT '',
  `main_customer` varchar(200) NOT NULL DEFAULT '',
  `link_man` varchar(25) NOT NULL DEFAULT '',
  `link_man_gender` tinyint(1) NOT NULL DEFAULT '0',
  `position` tinyint(1) NOT NULL DEFAULT '0',
  `tel` varchar(25) NOT NULL DEFAULT '',
  `fax` varchar(25) NOT NULL DEFAULT '',
  `mobile` varchar(25) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `site_url` varchar(100) NOT NULL DEFAULT '',
  `picture` varchar(50) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `first_letter` char(2) NOT NULL DEFAULT '',
  `if_commend` tinyint(1) NOT NULL DEFAULT '0',
  `clicked` int(5) NOT NULL DEFAULT '1',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`),
  KEY `name` (`name`),
  KEY `status` (`status`),
  KEY `picture` (`picture`),
  KEY `industry_id1` (`industry_id`,`area_id`),
  KEY `status_2` (`status`),
  KEY `picture_2` (`picture`,`status`),
  KEY `name_2` (`name`),
  KEY `name_3` (`name`),
  KEY `status_3` (`status`),
  KEY `picture_3` (`picture`),
  KEY `industry_id1_2` (`industry_id`,`area_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companies`
--

LOCK TABLES `companies` WRITE;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` VALUES (1,1,'admin',9,0,'',1,'3',1,'Ualink E-Commerce','PHPB2B','UALINK E-Commerce','','','Stephen','1',3,1,'a:1:{s:12:\"templet_name\";b:0;}','Bank Of Beijing','12342143','','4','946684800',5,'Beijing','Beijing East District','100010','Ualink','1,2,3','Beijing City','Company Unit','Stephen',1,4,'(086)10-41235678','(086)10-41235678','130123456782','service@phpb2b.com','http://www.phpb2b.com/','sample/company/1.jpg',1,'A',1,1,1313811282,1313811282),(2,1,'admin2',9,0,'',1,'3',1,'Beijing Ualink E-Commerce Inc.','Beijing Ualink E-Commerce Inc.','','','','','1',0,1,NULL,'','','','','',5,'Beijing','Beijing East District','100010','Ualink','2,3,4','Beijing City','','',1,4,'(086)10-41235678','(086)10-41235678','','service@phpb2b.com','http://www.phpb2b.com/','sample/company/1.jpg',1,'A',1,1,1313811282,0),(3,2,'athena1',9,0,'',1,'3',1,'3M China Ltd,Beijing Branch Office','This is the demo data, does not guarantee the authenticity of the data','','','','','1',0,1,NULL,'','','','','',0,'','','','','','','','',1,7,'','','','','','sample/company/no.jpg',1,'A',1,1,1313811282,0),(4,2,'athena2',9,0,'',1,'2',1,'AT&T(China)Co.,Ltd.','This is the demo data, does not guarantee the authenticity of the data','','','','','1',0,1,NULL,'','','','','',0,'','','','','','','','',1,7,'','','','','','sample/company/no.jpg',1,'A',1,1,1313811282,0),(5,2,'',9,0,'',1,'2',1,'BP Amoco China Co., Ltd','This is the demo data, does not guarantee the authenticity of the data','','','','','1',0,1,NULL,'','','','','',0,'','','','','','','','',1,7,'','','','','','sample/company/no.jpg',1,'A',1,1,1313811282,0),(6,2,'',9,0,'',2,'2',1,'IONA Technologies Corporation','This is the demo data, does not guarantee the authenticity of the data','','','','','1',0,1,NULL,'','','','','',0,'','','','','','','','',1,7,'','','','','','sample/company/no.jpg',1,'A',1,1,1313811282,0),(7,2,'',9,0,'',2,'2',1,'Alpine Electronics(China)Co.,Ltd.','This is the demo data, does not guarantee the authenticity of the data','','','','','1',0,1,NULL,'','','','','',0,'','','','','','','','',1,7,'','','','','','sample/company/no.jpg',1,'A',1,1,1313811282,0),(8,2,'',9,0,'',2,'1',1,'ARCO CHINA INC.','This is the demo data, does not guarantee the authenticity of the data','','','','','1',0,1,NULL,'','','','','',0,'','','','','','','','',1,7,'','','','','','sample/company/no.jpg',1,'A',1,1,1313811282,0),(9,2,'',9,0,'',2,'1',1,'Accenture Co., Ltd.','This is the demo data, does not guarantee the authenticity of the data','','','','','1',0,1,NULL,'','','','','',0,'','','','','','','','',1,7,'','','','','','sample/company/no.jpg',1,'A',1,1,1313811282,0),(10,2,'athena8',9,0,'',3,'1',1,'Irdeto Access Technology(Beijing)Co.,Ltd.','This is the demo data, does not guarantee the authenticity of the data','','','','','1',0,1,NULL,'','','','','',0,'','','','','','','','',1,7,'','','','','','sample/company/no.jpg',1,'A',1,1,1313811282,0),(11,2,'athena9',9,0,'',3,'1',1,'Ericsson(China)Company Ltd.','This is the demo data, does not guarantee the authenticity of the data','','','','','1',0,1,NULL,'','','','','',0,'','','','','','','','',1,7,'','','','','','sample/company/no.jpg',1,'A',1,1,1313811282,0);
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companyfields`
--

DROP TABLE IF EXISTS `companyfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `companyfields` (
  `company_id` int(10) NOT NULL DEFAULT '0',
  `map_longitude` varchar(25) NOT NULL DEFAULT '',
  `map_latitude` varchar(25) NOT NULL DEFAULT '',
  PRIMARY KEY (`company_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companyfields`
--

LOCK TABLES `companyfields` WRITE;
/*!40000 ALTER TABLE `companyfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `companyfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companynewses`
--

DROP TABLE IF EXISTS `companynewses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `companynewses` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `member_id` int(10) NOT NULL DEFAULT '-1',
  `company_id` int(10) NOT NULL DEFAULT '-1',
  `type_id` smallint(3) NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `content` text,
  `picture` varchar(100) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `clicked` int(5) NOT NULL DEFAULT '1',
  `created` int(11) NOT NULL DEFAULT '0',
  `modified` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companynewses`
--

LOCK TABLES `companynewses` WRITE;
/*!40000 ALTER TABLE `companynewses` DISABLE KEYS */;
/*!40000 ALTER TABLE `companynewses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companynewstypes`
--

DROP TABLE IF EXISTS `companynewstypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `companynewstypes` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `display_order` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companynewstypes`
--

LOCK TABLES `companynewstypes` WRITE;
/*!40000 ALTER TABLE `companynewstypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `companynewstypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companytypes`
--

DROP TABLE IF EXISTS `companytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `companytypes` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `display_order` tinyint(1) NOT NULL DEFAULT '0',
  `url` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companytypes`
--

LOCK TABLES `companytypes` WRITE;
/*!40000 ALTER TABLE `companytypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `companytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countries` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `picture` varchar(100) NOT NULL DEFAULT '0',
  `display_order` smallint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES (1,'China','cn.gif',0),(3,'Hongkong','hk.gif',0);
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dicts`
--

DROP TABLE IF EXISTS `dicts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dicts` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `dicttype_id` smallint(6) NOT NULL DEFAULT '0',
  `extend_dicttypeid` varchar(25) NOT NULL DEFAULT '',
  `word` varchar(255) NOT NULL DEFAULT '',
  `word_name` varchar(255) NOT NULL DEFAULT '',
  `digest` varchar(255) NOT NULL DEFAULT '',
  `content` text,
  `picture` varchar(255) NOT NULL DEFAULT '',
  `refer` tinytext,
  `hits` int(10) NOT NULL DEFAULT '1',
  `closed` tinyint(1) NOT NULL DEFAULT '0',
  `if_commend` tinyint(1) NOT NULL DEFAULT '0',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dicts`
--

LOCK TABLES `dicts` WRITE;
/*!40000 ALTER TABLE `dicts` DISABLE KEYS */;
INSERT INTO `dicts` VALUES (1,7,'','Red Apple phenomenon','Cost and Freight','','','','',7,0,0,1313811282,0),(2,1,'','Toucan tongue is a cluster','','','','','',4,0,0,1313811282,0);
/*!40000 ALTER TABLE `dicts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dicttypes`
--

DROP TABLE IF EXISTS `dicttypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dicttypes` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `parent_id` smallint(6) NOT NULL DEFAULT '0',
  `display_order` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dicttypes`
--

LOCK TABLES `dicttypes` WRITE;
/*!40000 ALTER TABLE `dicttypes` DISABLE KEYS */;
INSERT INTO `dicttypes` VALUES (1,'Nature',0,0),(2,'Culture',0,0),(3,'People',0,0),(4,'History',0,0),(5,'Life',0,0),(6,'Social',0,0),(7,'Arts',1,0),(8,'Economy',1,0),(9,'Science',1,0),(10,'Sports',1,0),(11,'Technology',1,0),(12,'Geography',1,0),(13,'Hot',1,0),(14,'Other',1,0);
/*!40000 ALTER TABLE `dicttypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expomembers`
--

DROP TABLE IF EXISTS `expomembers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expomembers` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `expo_id` smallint(6) NOT NULL DEFAULT '0',
  `member_id` int(10) NOT NULL DEFAULT '0',
  `company_id` int(10) NOT NULL DEFAULT '0',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `expo_id` (`expo_id`,`member_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expomembers`
--

LOCK TABLES `expomembers` WRITE;
/*!40000 ALTER TABLE `expomembers` DISABLE KEYS */;
/*!40000 ALTER TABLE `expomembers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expos`
--

DROP TABLE IF EXISTS `expos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expos` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `expotype_id` smallint(3) NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL DEFAULT '',
  `description` text,
  `begin_time` int(10) NOT NULL DEFAULT '0',
  `end_time` int(10) NOT NULL DEFAULT '0',
  `industry_ids` varchar(100) NOT NULL DEFAULT '0',
  `industry_id` smallint(6) NOT NULL DEFAULT '0',
  `area_id` smallint(6) NOT NULL DEFAULT '0',
  `address` varchar(100) NOT NULL DEFAULT '',
  `stadium_name` varchar(100) NOT NULL DEFAULT '',
  `refresh_method` varchar(100) NOT NULL DEFAULT '',
  `scope` varchar(100) NOT NULL DEFAULT '',
  `hosts` varchar(255) NOT NULL DEFAULT '',
  `organisers` varchar(255) NOT NULL DEFAULT '',
  `co_organisers` varchar(255) NOT NULL DEFAULT '',
  `sponsors` varchar(255) NOT NULL DEFAULT '',
  `contacts` text,
  `important_notice` text,
  `picture` varchar(100) NOT NULL DEFAULT '',
  `if_commend` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `hits` smallint(6) NOT NULL DEFAULT '1',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `status_2` (`status`),
  KEY `status_3` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expos`
--

LOCK TABLES `expos` WRITE;
/*!40000 ALTER TABLE `expos` DISABLE KEYS */;
INSERT INTO `expos` VALUES (1,1,'2011 Hong Kong International ICT Expo (ICT)','',1293936472,1296528472,'0',0,0,'','','','','','','','','','','',0,1,1,1313811282,0),(2,1,'2011 Hong Kong Electronics Fair Spring','',1293936472,1296528472,'0',0,0,'','','','','','','','','','','',0,1,1,1313811282,0),(3,1,'2011 Dubai Wood, furniture accessories and Woodworking Machinery Exhibition','',1293936472,1296528472,'0',0,0,'','','','','','','','','','','',0,1,1,1313811282,0),(4,1,'2011 Vietnam International Leather, Leather Chemical and Equipment Exhibition','',1293936472,1296528472,'0',0,0,'','','','','','','','','','','',0,1,1,1313811282,0),(5,2,'Dubai 2011 exhibition and entertainment facilities, theme park development','',1293936472,1296528472,'0',0,0,'','','','','','','','','','','',0,1,1,1313811282,0),(6,2,'2011 South African Medical Fair AFRICA HEALTH','',1293936472,1296528472,'0',0,0,'','','','','','','','','','','',0,1,1,1313811282,0),(7,1,'Russia 2011 Exhibition of professional cosmetics and beauty equipment','Russia 2011 Exhibition of professional cosmetics and beauty equipment',1293936472,1296528472,'0',0,0,'','','','','','','','','','','',0,1,1,1313811282,0),(8,2,'2011 Seoul International Book Fair SIBF','2011 Seoul International Book Fair SIBF',1293936472,1296528472,'0',0,0,'','','','','','','','',NULL,NULL,'',0,1,1,1313811282,0),(9,1,'Egyptian International Packaging Exhibition 2011','Egyptian International Packaging Exhibition 2011',1293936472,1296528472,'0',0,0,'','','','','','','','',NULL,NULL,'',0,1,1,1313811282,0),(10,2,'2011 China (Beijing) International Tea and Tea Expo','2011 China (Beijing) International Tea and Tea Expo',1293936472,1296528472,'0',0,0,'','','','','','','','',NULL,NULL,'',0,1,1,1313811282,0),(12,1,'Hanoi, Vietnam 2011 International Security Technology & Equipment Exhibition','Hanoi, Vietnam 2011 International Security Technology & Equipment Exhibition',1293936472,1296528472,'0',0,0,'','','','','','','','',NULL,NULL,'sample/other/fair-1.jpg',1,1,1,1313811282,0);
/*!40000 ALTER TABLE `expos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expostadiums`
--

DROP TABLE IF EXISTS `expostadiums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expostadiums` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `sa` varchar(100) DEFAULT '',
  `country_id` smallint(6) DEFAULT '0',
  `province_id` smallint(6) DEFAULT '0',
  `city_id` smallint(6) DEFAULT '0',
  `sb` varchar(200) DEFAULT '',
  `sc` varchar(150) DEFAULT '',
  `sd` varchar(150) DEFAULT '',
  `se` varchar(150) DEFAULT '',
  `sf` varchar(150) DEFAULT '',
  `sg` text,
  `sh` smallint(6) DEFAULT '0',
  `created` int(10) DEFAULT NULL,
  `modified` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expostadiums`
--

LOCK TABLES `expostadiums` WRITE;
/*!40000 ALTER TABLE `expostadiums` DISABLE KEYS */;
/*!40000 ALTER TABLE `expostadiums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expotypes`
--

DROP TABLE IF EXISTS `expotypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expotypes` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expotypes`
--

LOCK TABLES `expotypes` WRITE;
/*!40000 ALTER TABLE `expotypes` DISABLE KEYS */;
INSERT INTO `expotypes` VALUES (1,'Domestic',1313811282,0),(2,'International',1313811282,0);
/*!40000 ALTER TABLE `expotypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favorites`
--

DROP TABLE IF EXISTS `favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `favorites` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `member_id` int(10) NOT NULL DEFAULT '-1',
  `target_id` int(10) NOT NULL DEFAULT '0',
  `type_id` tinyint(1) NOT NULL DEFAULT '0',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `member_id` (`member_id`,`target_id`,`type_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favorites`
--

LOCK TABLES `favorites` WRITE;
/*!40000 ALTER TABLE `favorites` DISABLE KEYS */;
/*!40000 ALTER TABLE `favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feeds`
--

DROP TABLE IF EXISTS `feeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feeds` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type_id` tinyint(1) NOT NULL DEFAULT '0',
  `type` varchar(100) NOT NULL DEFAULT '',
  `member_id` int(10) NOT NULL DEFAULT '0',
  `username` varchar(100) NOT NULL DEFAULT '',
  `data` text NOT NULL,
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feeds`
--

LOCK TABLES `feeds` WRITE;
/*!40000 ALTER TABLE `feeds` DISABLE KEYS */;
/*!40000 ALTER TABLE `feeds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formattributes`
--

DROP TABLE IF EXISTS `formattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `formattributes` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type_id` tinyint(1) NOT NULL DEFAULT '0',
  `form_id` smallint(3) NOT NULL DEFAULT '0',
  `formitem_id` smallint(3) NOT NULL DEFAULT '0',
  `primary_id` int(10) NOT NULL DEFAULT '0',
  `attribute` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formattributes`
--

LOCK TABLES `formattributes` WRITE;
/*!40000 ALTER TABLE `formattributes` DISABLE KEYS */;
/*!40000 ALTER TABLE `formattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formitems`
--

DROP TABLE IF EXISTS `formitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `formitems` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `form_id` smallint(3) NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `description` text,
  `identifier` varchar(50) NOT NULL DEFAULT '',
  `type` enum('checkbox','select','radio','calendar','url','image','textarea','email','number','text') NOT NULL DEFAULT 'text',
  `rules` text,
  `display_order` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formitems`
--

LOCK TABLES `formitems` WRITE;
/*!40000 ALTER TABLE `formitems` DISABLE KEYS */;
INSERT INTO `formitems` VALUES (1,0,'Quality','','product_quantity','text','',0),(2,0,'Package','','packing','text','',0),(3,0,'Price','','product_price','text','',0),(4,0,'Scale','','product_specification','text','',0),(5,0,'Serial','','serial_number','text','',0),(6,0,'Produce','','production_place','text','',0),(7,0,'Brand',NULL,'brand_name','text',NULL,0);
/*!40000 ALTER TABLE `formitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms`
--

DROP TABLE IF EXISTS `forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `type_id` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL DEFAULT '',
  `items` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms`
--

LOCK TABLES `forms` WRITE;
/*!40000 ALTER TABLE `forms` DISABLE KEYS */;
INSERT INTO `forms` VALUES (1,1,'Trade Column','1,2,3,4,5,6'),(2,2,'Product Column','1,2,3,4,5,6,7');
/*!40000 ALTER TABLE `forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `friendlinks`
--

DROP TABLE IF EXISTS `friendlinks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `friendlinks` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `friendlinktype_id` tinyint(1) NOT NULL DEFAULT '0',
  `industry_id` smallint(6) NOT NULL DEFAULT '0',
  `area_id` smallint(6) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL DEFAULT '',
  `logo` varchar(100) NOT NULL DEFAULT '',
  `url` varchar(50) NOT NULL DEFAULT '',
  `priority` smallint(3) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `description` text,
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `friendlinks`
--

LOCK TABLES `friendlinks` WRITE;
/*!40000 ALTER TABLE `friendlinks` DISABLE KEYS */;
INSERT INTO `friendlinks` VALUES (1,1,0,0,'PHPB2B','','http://www.phpb2b.com/',0,1,'',1293936472,0),(2,2,0,0,'PHPB2B Demo','','http://demo.phpb2b.com/',0,1,'',1293936472,0);
/*!40000 ALTER TABLE `friendlinks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `friendlinktypes`
--

DROP TABLE IF EXISTS `friendlinktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `friendlinktypes` (
  `id` tinyint(1) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `friendlinktypes`
--

LOCK TABLES `friendlinktypes` WRITE;
/*!40000 ALTER TABLE `friendlinktypes` DISABLE KEYS */;
INSERT INTO `friendlinktypes` VALUES (1,'Links'),(2,'Partners');
/*!40000 ALTER TABLE `friendlinktypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods`
--

DROP TABLE IF EXISTS `goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goods` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `type_id` smallint(3) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `price` float(9,2) NOT NULL DEFAULT '0.00',
  `closed` tinyint(1) NOT NULL DEFAULT '1',
  `picture` varchar(100) NOT NULL DEFAULT '',
  `if_commend` tinyint(1) NOT NULL DEFAULT '0',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods`
--

LOCK TABLES `goods` WRITE;
/*!40000 ALTER TABLE `goods` DISABLE KEYS */;
INSERT INTO `goods` VALUES (2,1,'VIP Upgrade','',0.02,1,'',0,1293936472,1300889949),(1,1,'Professional Upgrade','',0.01,1,'',0,1293936472,1300889956);
/*!40000 ALTER TABLE `goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goodtypes`
--

DROP TABLE IF EXISTS `goodtypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goodtypes` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `display_order` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goodtypes`
--

LOCK TABLES `goodtypes` WRITE;
/*!40000 ALTER TABLE `goodtypes` DISABLE KEYS */;
INSERT INTO `goodtypes` VALUES (1,'Service',0),(2,'Cache',0),(3,'Ads',0);
/*!40000 ALTER TABLE `goodtypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `helps`
--

DROP TABLE IF EXISTS `helps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `helps` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `helptype_id` smallint(3) NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `content` text,
  `highlight` tinyint(1) NOT NULL DEFAULT '0',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `helps`
--

LOCK TABLES `helps` WRITE;
/*!40000 ALTER TABLE `helps` DISABLE KEYS */;
INSERT INTO `helps` VALUES (1,1,'Login step','',0,0,0),(2,2,'Register step','',0,0,0);
/*!40000 ALTER TABLE `helps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `helptypes`
--

DROP TABLE IF EXISTS `helptypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `helptypes` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `description` varchar(100) NOT NULL DEFAULT '',
  `parent_id` smallint(3) NOT NULL DEFAULT '0',
  `level` tinyint(1) NOT NULL DEFAULT '0',
  `display_order` tinyint(1) NOT NULL DEFAULT '0',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `helptypes`
--

LOCK TABLES `helptypes` WRITE;
/*!40000 ALTER TABLE `helptypes` DISABLE KEYS */;
INSERT INTO `helptypes` VALUES (1,'Site Help','',0,0,0,0,0),(2,'Outside the station to help','',0,0,0,0,0);
/*!40000 ALTER TABLE `helptypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `industries`
--

DROP TABLE IF EXISTS `industries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `industries` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `attachment_id` int(9) NOT NULL DEFAULT '0',
  `industrytype_id` smallint(3) NOT NULL DEFAULT '0',
  `child_ids` text,
  `name` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `alias_name` varchar(255) NOT NULL DEFAULT '',
  `highlight` tinyint(1) NOT NULL DEFAULT '0',
  `parent_id` smallint(6) NOT NULL DEFAULT '0',
  `top_parentid` smallint(6) NOT NULL DEFAULT '0',
  `level` tinyint(1) NOT NULL DEFAULT '1',
  `display_order` tinyint(1) NOT NULL DEFAULT '0',
  `description` text,
  `available` tinyint(1) NOT NULL DEFAULT '1',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=87 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `industries`
--

LOCK TABLES `industries` WRITE;
/*!40000 ALTER TABLE `industries` DISABLE KEYS */;
INSERT INTO `industries` VALUES (1,0,0,NULL,'Agriculture','','',0,0,0,1,0,NULL,1,0,0),(2,0,0,NULL,'Apparel&Fashion','','',0,0,0,1,0,NULL,1,0,0),(3,0,0,NULL,'Automobile','','',0,0,0,1,0,NULL,1,0,0),(4,0,0,NULL,'BusinessServices','','',0,0,0,1,0,NULL,1,0,0),(5,0,0,NULL,'Chemicals','','',0,0,0,1,0,NULL,1,0,0),(6,0,0,NULL,'ComputerHardwareSoftware','','',0,0,0,1,0,NULL,1,0,0),(7,0,0,NULL,'Construction&RealEstate','','',0,0,0,1,0,NULL,1,0,0),(8,0,0,NULL,'Electronics&Electrical','','',0,0,0,1,0,NULL,1,0,0),(9,0,0,NULL,'Energy','','',0,0,0,1,0,NULL,1,0,0),(10,0,0,NULL,'Environment','','',0,0,0,1,0,NULL,1,0,0),(11,0,0,NULL,'ExcessInventory','','',0,0,0,1,0,NULL,1,0,0),(12,0,0,NULL,'Food&Beverage','','',0,0,0,1,0,NULL,1,0,0),(13,0,0,NULL,'Gifts&Crafts','','',0,0,0,1,0,NULL,1,0,0),(14,0,0,NULL,'Health&Beauty','','',0,0,0,1,0,NULL,1,0,0),(15,0,0,NULL,'HomeAppliances','','',0,0,0,1,0,NULL,1,0,0),(16,0,0,NULL,'HomeSupplies','','',0,0,0,1,0,NULL,1,0,0),(17,0,0,NULL,'IndustrialSupplies','','',0,0,0,1,0,NULL,1,0,0),(18,0,0,NULL,'Minerals,Metals&Materials','','',0,0,0,1,0,NULL,1,0,0),(19,0,0,NULL,'OfficeSupplies','','',0,0,0,1,0,NULL,1,0,0),(20,0,0,NULL,'Packaging&Paper','','',0,0,0,1,0,NULL,1,0,0),(21,0,0,NULL,'Printing&Publishing','','',0,0,0,1,0,NULL,1,0,0),(22,0,0,NULL,'Security&Protection','','',0,0,0,1,0,NULL,1,0,0),(23,0,0,NULL,'Sports&Entertainment','','',0,0,0,1,0,NULL,1,0,0),(24,0,0,NULL,'Telecommunications','','',0,0,0,1,0,NULL,1,0,0),(25,0,0,NULL,'Textiles&LeatherProducts','','',0,0,0,1,0,NULL,1,0,0),(26,0,0,NULL,'Toys','','',0,0,0,1,0,NULL,1,0,0),(27,0,0,NULL,'Transportation','','',0,0,0,1,0,NULL,1,0,0),(28,0,0,NULL,'Agriculture&By-productAgent','','',0,1,1,2,0,NULL,1,0,0),(29,0,0,NULL,'AgricultureProductStocks','','',0,1,1,2,0,NULL,1,0,0),(30,0,0,NULL,'Agrochemicals&Pesticides','','',0,1,1,2,0,NULL,1,0,0),(31,0,0,NULL,'AnimalExtract','','',0,1,1,2,0,NULL,1,0,0),(32,0,0,NULL,'AnimalFodders','','',0,1,1,2,0,NULL,1,0,0),(33,0,0,NULL,'AnimalHusbandry','','',0,1,1,2,0,NULL,1,0,0),(34,0,0,NULL,'Bamboo&RattanProducts','','',0,1,1,2,0,NULL,1,0,0),(35,0,0,NULL,'Beans','','',0,1,1,2,0,NULL,1,0,0),(36,0,0,NULL,'Cigarette&Tobacco','','',0,1,1,2,0,NULL,1,0,0),(37,0,0,NULL,'Eggs','','',0,1,1,2,0,NULL,1,0,0),(38,0,0,NULL,'FarmMachines&Tools','','',0,1,1,2,0,NULL,1,0,0),(39,0,0,NULL,'FisheryMachinery','','',0,1,1,2,0,NULL,1,0,0),(40,0,0,NULL,'Flowers&Plant','','',0,1,1,2,0,NULL,1,0,0),(41,0,0,NULL,'ForestMachinery','','',0,1,1,2,0,NULL,1,0,0),(42,0,0,NULL,'Fruit','','',0,1,1,2,0,NULL,1,0,0),(43,0,0,NULL,'Grain','','',0,1,1,2,0,NULL,1,0,0),(44,0,0,NULL,'Mushroom&Truffle','','',0,1,1,2,0,NULL,1,0,0),(45,0,0,NULL,'Nuts&Kernels','','',0,1,1,2,0,NULL,1,0,0),(46,0,0,NULL,'Others','','',0,1,1,2,0,NULL,1,0,0),(47,0,0,NULL,'Plant&AnimalOil','','',0,1,1,2,0,NULL,1,0,0),(48,0,0,NULL,'PlantExtract','','',0,1,1,2,0,NULL,1,0,0),(49,0,0,NULL,'PlantSeed','','',0,1,1,2,0,NULL,1,0,0),(50,0,0,NULL,'Poultry&Livestock','','',0,1,1,2,0,NULL,1,0,0),(51,0,0,NULL,'Vegetable','','',0,1,1,2,0,NULL,1,0,0),(52,0,0,NULL,'Apparel & Fashion Agents','','',0,16,16,2,0,NULL,1,0,0),(53,0,0,NULL,'Apparel Stocks','','',0,16,16,2,0,NULL,1,0,0),(54,0,0,NULL,'Athletic Wear','','',0,16,16,2,0,NULL,1,0,0),(55,0,0,NULL,'Bathrobe','','',0,16,16,2,0,NULL,1,0,0),(56,0,0,NULL,'Children Garment','','',0,16,16,2,0,NULL,1,0,0),(57,0,0,NULL,'Costume & Ceremony','','',0,16,16,2,0,NULL,1,0,0),(58,0,0,NULL,'Down Garment','','',0,16,16,2,0,NULL,1,0,0),(59,0,0,NULL,'Ethnic Garment','','',0,16,16,2,0,NULL,1,0,0),(60,0,0,NULL,'Fashion Accessories','','',0,16,16,2,0,NULL,1,0,0),(61,0,0,NULL,'Belts & Accessories Hats & Caps moreFootwear','','',0,16,16,2,0,NULL,1,0,0),(62,0,0,NULL,'Sports Shoes Boots moreFur Garment','','',0,16,16,2,0,NULL,1,0,0),(63,0,0,NULL,'Garment Accessories','','',0,16,16,2,0,NULL,1,0,0),(64,0,0,NULL,'Buttons & Buckles Others moreGloves & Mittens','','',0,16,16,2,0,NULL,1,0,0),(65,0,0,NULL,'Infant Garment','','',0,16,16,2,0,NULL,1,0,0),(66,0,0,NULL,'Jacket','','',0,16,16,2,0,NULL,1,0,0),(67,0,0,NULL,'Jeans','','',0,16,16,2,0,NULL,1,0,0),(68,0,0,NULL,'Leather Garment','','',0,16,16,2,0,NULL,1,0,0),(69,0,0,NULL,'Leisure Wear','','',0,16,16,2,0,NULL,1,0,0),(70,0,0,NULL,'Others','','',0,16,16,2,0,NULL,1,0,0),(71,0,0,NULL,'Outerwear','','',0,16,16,2,0,NULL,1,0,0),(72,0,0,NULL,'Pants & Trousers','','',0,16,16,2,0,NULL,1,0,0),(73,0,0,NULL,'Related Machine','','',0,16,16,2,0,NULL,1,0,0),(74,0,0,NULL,'Sewing Machinery','','',0,16,16,2,0,NULL,1,0,0),(75,0,0,NULL,'Shirts & Blouses','','',0,16,16,2,0,NULL,1,0,0),(76,0,0,NULL,'Silk Garment','','',0,16,16,2,0,NULL,1,0,0),(77,0,0,NULL,'Skirts & Dresses','','',0,16,16,2,0,NULL,1,0,0),(78,0,0,NULL,'Socks & Stockings','','',0,16,16,2,0,NULL,1,0,0),(79,0,0,NULL,'Speciality','','',0,16,16,2,0,NULL,1,0,0),(80,0,0,NULL,'Suits & Tuxedo','','',0,16,16,2,0,NULL,1,0,0),(81,0,0,NULL,'Sweaters','','',0,16,16,2,0,NULL,1,0,0),(82,0,0,NULL,'Swimwear & Beachwear','','',0,16,16,2,0,NULL,1,0,0),(83,0,0,NULL,'T-Shirts','','',0,16,16,2,0,NULL,1,0,0),(84,0,0,NULL,'Underwear & Nightwear','','',0,16,16,2,0,NULL,1,0,0),(85,0,0,NULL,'Bras & Lingerie Underwear Set moreUniforms & Workwear','','',0,16,16,2,0,NULL,1,0,0),(86,0,0,NULL,'Used Clothes','','',0,16,16,2,0,NULL,1,0,0);
/*!40000 ALTER TABLE `industries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `industrytypes`
--

DROP TABLE IF EXISTS `industrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `industrytypes` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `industrytypes`
--

LOCK TABLES `industrytypes` WRITE;
/*!40000 ALTER TABLE `industrytypes` DISABLE KEYS */;
INSERT INTO `industrytypes` VALUES (2,'Consumer goods'),(3,'Raw materials'),(4,'Business Services'),(5,'Other');
/*!40000 ALTER TABLE `industrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inqueries`
--

DROP TABLE IF EXISTS `inqueries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inqueries` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `to_member_id` int(10) DEFAULT NULL,
  `to_company_id` int(10) DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `content` text,
  `send_achive` tinyint(1) DEFAULT NULL,
  `know_more` varchar(50) NOT NULL DEFAULT '',
  `exp_quantity` varchar(15) NOT NULL DEFAULT '',
  `exp_price` float(9,2) NOT NULL DEFAULT '0.00',
  `contacts` text,
  `user_ip` varchar(11) DEFAULT '',
  `created` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inqueries`
--

LOCK TABLES `inqueries` WRITE;
/*!40000 ALTER TABLE `inqueries` DISABLE KEYS */;
/*!40000 ALTER TABLE `inqueries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `member_id` int(10) NOT NULL DEFAULT '-1',
  `company_id` int(10) NOT NULL DEFAULT '-1',
  `cache_spacename` varchar(25) NOT NULL DEFAULT '',
  `industry_id` smallint(6) NOT NULL DEFAULT '0',
  `area_id` smallint(6) NOT NULL DEFAULT '0',
  `name` varchar(150) NOT NULL DEFAULT '',
  `work_station` varchar(50) NOT NULL DEFAULT '',
  `content` text,
  `require_gender_id` tinyint(1) NOT NULL DEFAULT '0',
  `peoples` varchar(5) NOT NULL DEFAULT '',
  `require_education_id` tinyint(1) NOT NULL DEFAULT '0',
  `require_age` varchar(10) NOT NULL DEFAULT '',
  `salary_id` tinyint(1) NOT NULL DEFAULT '0',
  `worktype_id` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `clicked` int(5) NOT NULL DEFAULT '1',
  `expire_time` int(10) NOT NULL DEFAULT '0',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobtypes`
--

DROP TABLE IF EXISTS `jobtypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobtypes` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `parent_id` smallint(6) NOT NULL DEFAULT '0',
  `level` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(255) NOT NULL DEFAULT '',
  `display_order` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobtypes`
--

LOCK TABLES `jobtypes` WRITE;
/*!40000 ALTER TABLE `jobtypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobtypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `keywords`
--

DROP TABLE IF EXISTS `keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `keywords` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `title` varchar(25) NOT NULL DEFAULT '',
  `target_id` int(10) NOT NULL DEFAULT '0',
  `target_position` tinyint(1) NOT NULL DEFAULT '0',
  `type_name` enum('trades','companies','newses','products') NOT NULL DEFAULT 'trades',
  `hits` smallint(6) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `title` (`title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `keywords`
--

LOCK TABLES `keywords` WRITE;
/*!40000 ALTER TABLE `keywords` DISABLE KEYS */;
/*!40000 ALTER TABLE `keywords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `handle_type` enum('error','info','warning') NOT NULL DEFAULT 'info',
  `source_module` varchar(50) NOT NULL DEFAULT '',
  `description` text,
  `ip_address` int(10) NOT NULL DEFAULT '0',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `markets`
--

DROP TABLE IF EXISTS `markets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `markets` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `main_business` varchar(255) NOT NULL DEFAULT '',
  `content` text,
  `markettype_id` smallint(3) NOT NULL DEFAULT '0',
  `area_id` smallint(6) NOT NULL DEFAULT '0',
  `industry_id` smallint(6) NOT NULL DEFAULT '0',
  `picture` varchar(50) NOT NULL DEFAULT '',
  `ip_address` int(10) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `clicked` smallint(6) NOT NULL DEFAULT '1',
  `if_commend` tinyint(1) NOT NULL DEFAULT '0',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `markets`
--

LOCK TABLES `markets` WRITE;
/*!40000 ALTER TABLE `markets` DISABLE KEYS */;
INSERT INTO `markets` VALUES (5,'','Information,software','',1,1,1,'sample/market/01.jpg',0,1,1,1,1313811282,0),(6,'','Information,software','',1,1,1,'sample/market/02.jpg',0,1,1,1,1313811282,0),(3,'','Information,software','',1,1,1,'sample/market/03.jpg',0,1,1,1,1313811282,0),(4,'','Information,software','',1,1,1,'sample/market/04.jpg',0,1,1,1,1313811282,0),(1,'ĳ','Information,software',NULL,0,1,1,'sample/market/05.jpg',0,0,1,0,0,0),(2,'ĳרҵ','Information,software',NULL,0,1,1,'sample/market/06.jpg',0,0,1,0,0,0);
/*!40000 ALTER TABLE `markets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `markettypes`
--

DROP TABLE IF EXISTS `markettypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `markettypes` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `display_order` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `markettypes`
--

LOCK TABLES `markettypes` WRITE;
/*!40000 ALTER TABLE `markettypes` DISABLE KEYS */;
INSERT INTO `markettypes` VALUES (1,'Internal',0),(2,'External',0),(3,'Super',0);
/*!40000 ALTER TABLE `markettypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membercaches`
--

DROP TABLE IF EXISTS `membercaches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `membercaches` (
  `member_id` int(10) NOT NULL DEFAULT '-1',
  `data1` text NOT NULL,
  `data2` text NOT NULL,
  `expiration` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`member_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membercaches`
--

LOCK TABLES `membercaches` WRITE;
/*!40000 ALTER TABLE `membercaches` DISABLE KEYS */;
/*!40000 ALTER TABLE `membercaches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `memberfields`
--

DROP TABLE IF EXISTS `memberfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `memberfields` (
  `member_id` int(10) NOT NULL DEFAULT '0',
  `today_logins` smallint(6) NOT NULL DEFAULT '0',
  `total_logins` smallint(6) NOT NULL DEFAULT '0',
  `area_id` smallint(6) NOT NULL DEFAULT '0',
  `first_name` varchar(25) NOT NULL DEFAULT '',
  `last_name` varchar(25) NOT NULL DEFAULT '',
  `gender` tinyint(1) NOT NULL DEFAULT '0',
  `tel` varchar(25) NOT NULL DEFAULT '',
  `fax` varchar(25) NOT NULL DEFAULT '',
  `mobile` varchar(25) NOT NULL DEFAULT '',
  `qq` varchar(12) NOT NULL DEFAULT '',
  `msn` varchar(50) NOT NULL DEFAULT '',
  `icq` varchar(12) NOT NULL DEFAULT '',
  `yahoo` varchar(50) NOT NULL DEFAULT '',
  `skype` varchar(50) NOT NULL DEFAULT '',
  `address` varchar(50) NOT NULL DEFAULT '',
  `zipcode` varchar(16) NOT NULL DEFAULT '',
  `site_url` varchar(100) NOT NULL DEFAULT '',
  `question` varchar(50) NOT NULL DEFAULT '',
  `answer` varchar(50) NOT NULL DEFAULT '',
  `reg_ip` varchar(25) NOT NULL DEFAULT '0',
  PRIMARY KEY (`member_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `memberfields`
--

LOCK TABLES `memberfields` WRITE;
/*!40000 ALTER TABLE `memberfields` DISABLE KEYS */;
INSERT INTO `memberfields` VALUES (1,0,0,6,'Zhang','San',1,'','','','','','','','','','','','','',''),(2,0,0,0,'Li','Si',0,'','','','','','','','','','','','','','');
/*!40000 ALTER TABLE `memberfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membergroups`
--

DROP TABLE IF EXISTS `membergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `membergroups` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `membertype_id` tinyint(1) NOT NULL DEFAULT '-1',
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` text,
  `type` enum('define','special','system') NOT NULL DEFAULT 'define',
  `system` enum('private','public') NOT NULL DEFAULT 'private',
  `picture` varchar(50) NOT NULL DEFAULT 'default.gif',
  `point_max` smallint(6) NOT NULL DEFAULT '0',
  `point_min` smallint(6) NOT NULL DEFAULT '0',
  `max_offer` smallint(3) NOT NULL DEFAULT '0',
  `max_product` smallint(3) NOT NULL DEFAULT '0',
  `max_job` smallint(3) NOT NULL DEFAULT '0',
  `max_companynews` smallint(3) NOT NULL DEFAULT '0',
  `max_producttype` smallint(3) NOT NULL DEFAULT '3',
  `max_album` smallint(3) NOT NULL DEFAULT '0',
  `max_attach_size` smallint(6) NOT NULL DEFAULT '0',
  `max_size_perday` smallint(6) NOT NULL DEFAULT '0',
  `max_favorite` smallint(3) NOT NULL DEFAULT '0',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `allow_offer` tinyint(1) NOT NULL DEFAULT '0',
  `allow_market` tinyint(1) NOT NULL DEFAULT '0',
  `allow_company` tinyint(1) NOT NULL DEFAULT '0',
  `allow_product` tinyint(1) NOT NULL DEFAULT '0',
  `allow_job` tinyint(1) NOT NULL DEFAULT '0',
  `allow_companynews` tinyint(1) NOT NULL DEFAULT '1',
  `allow_album` tinyint(1) NOT NULL DEFAULT '0',
  `allow_space` tinyint(1) NOT NULL DEFAULT '1',
  `default_live_time` tinyint(1) NOT NULL DEFAULT '1',
  `after_live_time` tinyint(1) NOT NULL DEFAULT '1',
  `exempt` tinyint(1) unsigned zerofill NOT NULL DEFAULT '0',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membergroups`
--

LOCK TABLES `membergroups` WRITE;
/*!40000 ALTER TABLE `membergroups` DISABLE KEYS */;
INSERT INTO `membergroups` VALUES (1,1,'Associate','','system','private','informal.gif',0,-32767,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,2,0,0,1274002638),(2,1,'Formal','','system','private','formal.gif',32767,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,0,2,25,0,1274002638),(3,1,'Pending','Awaiting verification','special','private','special_checking.gif',0,0,0,0,0,0,3,0,0,0,0,0,1,1,1,1,1,1,1,1,1,2,0,0,1274002638),(4,1,'Forbidden','Block access to Web site','special','private','special_novisit.gif',0,0,0,0,0,0,3,0,0,0,0,0,1,1,1,1,1,1,1,1,1,2,0,0,1274002638),(5,1,'Embargo','Prohibit any of the information published in the Business Room','special','private','special_noperm.gif',0,0,0,0,0,0,3,0,0,0,0,0,1,1,1,1,1,1,1,1,1,2,0,0,1274002638),(6,1,'Prohibition of landing','Prohibition of Commercial Office Login','special','private','special_nologin.gif',0,0,0,0,0,0,3,0,0,0,0,0,1,1,1,1,1,1,1,1,1,2,0,0,1274002638),(7,1,'Individual Members','General Level Member','define','public','copper.gif',0,0,5,0,0,0,3,0,0,0,0,1,3,1,3,3,3,3,1,1,1,9,24,0,1274002638),(8,1,'Senior Individual Member','Senior Individual Member','define','public','silver.gif',0,0,0,0,0,0,3,0,0,0,0,0,1,1,1,1,1,1,1,1,2,6,25,0,1274002638),(9,1,'Ordinary Corporate Member','Member companies at this level generally','define','public','gold.gif',0,0,2,2,0,0,3,0,0,0,0,0,2,3,3,2,2,2,2,1,1,2,31,0,1274002638),(10,2,'VIP Corporate Membership','Senior Corporate Member','define','public','vip.gif',0,0,0,0,0,0,3,0,0,0,0,0,3,3,3,3,3,3,3,1,1,2,31,0,1274002638);
/*!40000 ALTER TABLE `membergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `members` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `space_name` varchar(255) NOT NULL DEFAULT '',
  `templet_id` smallint(3) NOT NULL DEFAULT '0',
  `username` varchar(25) NOT NULL DEFAULT '',
  `userpass` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `points` smallint(6) NOT NULL DEFAULT '0',
  `credits` smallint(6) NOT NULL DEFAULT '0',
  `balance_amount` float(7,2) NOT NULL DEFAULT '0.00',
  `trusttype_ids` varchar(25) NOT NULL DEFAULT '',
  `status` enum('3','2','1','0') NOT NULL DEFAULT '0',
  `photo` varchar(100) NOT NULL DEFAULT '',
  `membertype_id` smallint(3) NOT NULL DEFAULT '0',
  `membergroup_id` smallint(3) NOT NULL DEFAULT '0',
  `last_login` varchar(11) NOT NULL DEFAULT '0',
  `last_ip` varchar(25) NOT NULL DEFAULT '0',
  `service_start_date` varchar(11) NOT NULL DEFAULT '0',
  `service_end_date` varchar(11) NOT NULL DEFAULT '0',
  `office_redirect` smallint(6) NOT NULL DEFAULT '0',
  `created` varchar(10) NOT NULL DEFAULT '0',
  `modified` varchar(10) NOT NULL DEFAULT '0',
  `oauth_provider` varchar(50) DEFAULT NULL,
  `oauth_uid` varchar(50) DEFAULT NULL,
  `oauth_username` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members`
--

LOCK TABLES `members` WRITE;
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
INSERT INTO `members` VALUES (12,'',0,'test64594','','test64594@example.com',0,0,0.00,'','0','',0,0,'0','0','0','0',0,'2011-08-28','0',NULL,NULL,NULL),(20,'',0,'test3577','','test3577@example.com',0,0,0.00,'','0','',0,0,'0','0','0','0',0,'2011-08-29','0',NULL,NULL,NULL),(21,'',0,'test56573','','test56573@example.com',0,0,0.00,'','0','',0,0,'0','0','0','0',0,'2011-08-29','0',NULL,NULL,NULL),(7,'',0,'test89364','','test89364@example.com',0,0,0.00,'','0','',0,0,'0','0','0','0',0,'2011-08-28','0',NULL,NULL,NULL),(8,'',0,'test20095','','test20095@example.com',0,0,0.00,'','0','',0,0,'0','0','0','0',0,'2011-08-28','0',NULL,NULL,NULL),(9,'',0,'test75325','','test75325@example.com',0,0,0.00,'','0','',0,0,'0','0','0','0',0,'2011-08-28','0',NULL,NULL,NULL);
/*!40000 ALTER TABLE `members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membertypes`
--

DROP TABLE IF EXISTS `membertypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `membertypes` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `default_membergroup_id` smallint(3) NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membertypes`
--

LOCK TABLES `membertypes` WRITE;
/*!40000 ALTER TABLE `membertypes` DISABLE KEYS */;
INSERT INTO `membertypes` VALUES (1,7,'Personal','Personal Member'),(2,9,'Company','Company Member'),(3,10,'Shop','Shoper');
/*!40000 ALTER TABLE `membertypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type` enum('system','user','inquery') NOT NULL DEFAULT 'user',
  `from_member_id` int(10) NOT NULL DEFAULT '-1',
  `cache_from_username` varchar(25) NOT NULL DEFAULT '',
  `to_member_id` int(10) NOT NULL DEFAULT '-1',
  `cache_to_username` varchar(25) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` text,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `created` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navs`
--

DROP TABLE IF EXISTS `navs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `navs` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `parent_id` smallint(3) NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `target` enum('_blank','_self') NOT NULL DEFAULT '_self',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `display_order` smallint(3) NOT NULL DEFAULT '0',
  `highlight` tinyint(1) NOT NULL DEFAULT '0',
  `level` tinyint(1) NOT NULL DEFAULT '0',
  `class_name` varchar(25) NOT NULL DEFAULT '',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navs`
--

LOCK TABLES `navs` WRITE;
/*!40000 ALTER TABLE `navs` DISABLE KEYS */;
INSERT INTO `navs` VALUES (1,0,'Home','','index.php','_self',1,1,0,0,'',1313811282,0),(2,0,'Buy','','offer/list.php?typeid=1&navid=2','_self',1,2,0,0,'',1313811282,1313811282),(3,0,'Sell','','offer/list.php?typeid=2&navid=3','_self',1,3,0,0,'',1313811282,1313811282),(4,0,'Invest','','offer/index.php?mod=invest','_self',1,5,0,0,'',1313811282,1313811282),(5,0,'Fair','','fair/','_self',1,6,0,0,'',1313811282,1313811282),(6,0,'Price','','market/quote.php','_self',1,8,0,0,'',1313811282,0),(7,0,'Market','','market/index.php','_self',1,9,0,0,'',1313811282,1313811282),(8,0,'Fair','','fair/index.php','_self',0,10,0,0,'',1313811282,0),(9,0,'Job','','hr/','_self',1,11,0,0,'',1313811282,1313811282),(10,0,'brand','','brand/','_self',1,7,0,0,'',1313811282,1313811282),(11,0,'Wholesale','','offer/index.php?mod=wholesale','_self',1,4,0,0,'',1313811282,1313811282),(12,0,'Dict','Dict','dict/','_self',1,12,0,0,'',1313811282,1313811282);
/*!40000 ALTER TABLE `navs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `newses`
--

DROP TABLE IF EXISTS `newses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `newses` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type_id` smallint(3) NOT NULL DEFAULT '0',
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `industry_id` smallint(3) NOT NULL DEFAULT '0',
  `area_id` smallint(3) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` text,
  `source` varchar(25) NOT NULL DEFAULT '',
  `picture` varchar(50) NOT NULL DEFAULT '',
  `if_focus` tinyint(1) NOT NULL DEFAULT '0',
  `if_commend` tinyint(1) NOT NULL DEFAULT '0',
  `highlight` tinyint(1) NOT NULL DEFAULT '0',
  `clicked` int(10) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `flag` tinyint(1) NOT NULL DEFAULT '0',
  `require_membertype` varchar(15) NOT NULL DEFAULT '0',
  `tag_ids` varchar(255) DEFAULT '',
  `created` int(10) NOT NULL DEFAULT '0',
  `create_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `type_id` (`type_id`,`status`),
  KEY `type_id_2` (`type_id`,`status`),
  KEY `status` (`status`),
  KEY `picture` (`picture`,`status`),
  KEY `type_id_3` (`type_id`,`status`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `newses`
--

LOCK TABLES `newses` WRITE;
/*!40000 ALTER TABLE `newses` DISABLE KEYS */;
INSERT INTO `newses` VALUES (14,2,0,0,0,'Tear gas could be used to tame drunk drivers','','','sample/news/1.jpg',0,0,0,123,1,0,'0','',1313811282,'2011-01-02 02:47:28',0),(15,2,0,0,0,'China eyes fair treatment for its firms in US','','','sample/news/2.jpg',0,0,0,123,1,0,'0','',1313811282,'2011-01-02 02:47:28',0),(3,2,0,0,0,'France expels 14 Libyan diplomats','','','sample/news/3.jpg',0,0,0,123,1,0,'0','',1313811282,'2011-01-02 02:47:28',0),(4,2,0,0,0,'China punishes Unilever for price hike remarks','','','sample/news/4.jpg',0,0,0,123,1,0,'0','',1313811282,'2011-01-02 02:47:28',0),(5,2,0,0,0,'Pakistan warns US not to stage more raids','','','sample/news/5.jpg',0,0,0,123,1,0,'0','',1313811282,'2011-01-02 02:47:28',0),(6,2,0,0,0,'Rise of China top news of the century','','','sample/news/6.jpg',0,0,0,123,1,0,'0','',1313811282,'2011-01-02 02:47:28',0),(7,2,0,0,0,'2 Chinese sites may make World Heritage List','','','sample/news/7.jpg',0,0,0,123668,1,0,'0','',1313811282,'2011-01-02 02:47:28',0),(8,2,0,0,0,'US halts F-22 flights over system concerns','','','sample/news/8.jpg',0,0,0,123,1,0,'0','',1313811282,'2011-01-02 02:47:28',0),(9,1,0,0,0,'Paralyzed gymnast files harassment report','','','sample/news/9.jpg',0,0,0,123,1,0,'0','',1313811282,'2011-01-02 02:47:28',0),(10,1,0,0,0,'terfall festival flows in Guizhou','','','sample/news/10.jpg',0,0,0,123,1,0,'0','',1313811282,'2011-01-02 02:47:28',0),(11,1,0,0,0,'Red Cross pours 18.7b yuan into Sichuan','','','sample/news/11.jpg',0,0,0,123,1,0,'0','',1313811282,'2011-01-02 02:47:28',0),(12,1,0,0,0,'Paralyzed gymnast files harassment report','','','sample/news/12.jpg',0,0,0,123,1,0,'0','',1313811282,'2011-01-02 02:47:28',0),(2,1,0,0,0,'Officials in Chongqing become part-time farmers',NULL,'','sample/news/14.jpg',0,1,0,123,1,0,'0','',1313811282,'2011-01-02 02:47:28',0),(1,1,0,0,0,'Expert: AIDS-like disease is not just phobia','','','sample/news/14.jpg',0,1,0,123,1,0,'0','',1313811282,'2011-01-02 02:47:28',0),(13,5,0,0,0,'The Week: A weekly round-up of fun, funky news','','','sample/news/13.jpg',0,0,0,123,1,0,'0','',1313811282,'2011-01-02 02:47:28',0);
/*!40000 ALTER TABLE `newses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `newstypes`
--

DROP TABLE IF EXISTS `newstypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `newstypes` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL DEFAULT '',
  `level_id` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `parent_id` smallint(3) NOT NULL DEFAULT '0',
  `created` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `newstypes`
--

LOCK TABLES `newstypes` WRITE;
/*!40000 ALTER TABLE `newstypes` DISABLE KEYS */;
INSERT INTO `newstypes` VALUES (1,'Multimedia',1,1,0,1313811282),(2,'Chinese Media',1,1,0,1313811282),(3,'Business',1,1,0,1313811282),(4,'Regional',1,1,0,1313811282),(5,'Opnion',1,1,0,1313811282),(6,'Entertainment',1,1,0,1313811282),(7,'Metro Beijing',1,1,0,1313811282),(8,'Life',1,1,0,1313811282);
/*!40000 ALTER TABLE `newstypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordergoods`
--

DROP TABLE IF EXISTS `ordergoods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ordergoods` (
  `goods_id` smallint(6) NOT NULL DEFAULT '0',
  `order_id` smallint(6) unsigned zerofill NOT NULL DEFAULT '000000',
  `trade_no` char(16) NOT NULL DEFAULT '',
  `amount` smallint(3) NOT NULL DEFAULT '1',
  PRIMARY KEY (`goods_id`,`order_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordergoods`
--

LOCK TABLES `ordergoods` WRITE;
/*!40000 ALTER TABLE `ordergoods` DISABLE KEYS */;
/*!40000 ALTER TABLE `ordergoods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `passports`
--

DROP TABLE IF EXISTS `passports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `passports` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL DEFAULT '',
  `title` varchar(25) NOT NULL DEFAULT '',
  `description` text,
  `url` varchar(25) NOT NULL DEFAULT '',
  `config` text,
  `available` tinyint(1) NOT NULL DEFAULT '1',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `passports`
--

LOCK TABLES `passports` WRITE;
/*!40000 ALTER TABLE `passports` DISABLE KEYS */;
/*!40000 ALTER TABLE `passports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payhistories`
--

DROP TABLE IF EXISTS `payhistories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payhistories` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `member_id` int(9) NOT NULL DEFAULT '-1',
  `trade_no` char(25) NOT NULL DEFAULT '-1',
  `amount` float(7,2) NOT NULL DEFAULT '0.00',
  `remain` float(7,2) NOT NULL DEFAULT '0.00',
  `ip_address` varchar(15) NOT NULL DEFAULT '1',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `one_trade_no` (`trade_no`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payhistories`
--

LOCK TABLES `payhistories` WRITE;
/*!40000 ALTER TABLE `payhistories` DISABLE KEYS */;
/*!40000 ALTER TABLE `payhistories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL DEFAULT '',
  `title` varchar(25) NOT NULL DEFAULT '',
  `description` text,
  `config` text,
  `available` tinyint(1) NOT NULL DEFAULT '1',
  `if_online_support` tinyint(1) NOT NULL DEFAULT '0',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personals`
--

DROP TABLE IF EXISTS `personals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personals` (
  `member_id` int(10) NOT NULL DEFAULT '0',
  `resume_status` tinyint(1) NOT NULL DEFAULT '0',
  `max_education` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`member_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personals`
--

LOCK TABLES `personals` WRITE;
/*!40000 ALTER TABLE `personals` DISABLE KEYS */;
/*!40000 ALTER TABLE `personals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugins` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL DEFAULT '',
  `title` varchar(25) NOT NULL DEFAULT '',
  `description` text,
  `copyright` varchar(25) NOT NULL DEFAULT '',
  `version` varchar(15) NOT NULL DEFAULT '',
  `pluginvar` text,
  `available` tinyint(1) NOT NULL DEFAULT '1',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pointlogs`
--

DROP TABLE IF EXISTS `pointlogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pointlogs` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `member_id` int(10) NOT NULL DEFAULT '0',
  `action_name` varchar(25) NOT NULL DEFAULT '',
  `points` smallint(3) NOT NULL DEFAULT '0',
  `description` text,
  `ip_address` varchar(15) NOT NULL DEFAULT '',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pointlogs`
--

LOCK TABLES `pointlogs` WRITE;
/*!40000 ALTER TABLE `pointlogs` DISABLE KEYS */;
/*!40000 ALTER TABLE `pointlogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productcategories`
--

DROP TABLE IF EXISTS `productcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `productcategories` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `parent_id` smallint(6) NOT NULL DEFAULT '0',
  `level` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(255) NOT NULL DEFAULT '',
  `display_order` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productcategories`
--

LOCK TABLES `productcategories` WRITE;
/*!40000 ALTER TABLE `productcategories` DISABLE KEYS */;
INSERT INTO `productcategories` VALUES (1,0,1,'ELECTRONIC ELEMENTS',0),(2,0,1,'Beauty Care',0),(3,0,1,'Medical Care',0),(4,0,1,'Instrumentation ',0),(5,0,1,'Household items ',0),(6,0,1,'Gifts Toys',0),(7,0,1,'Auto Parts',0),(8,0,1,'Iron and steel metallurgy',0),(9,0,1,'Packaging',0),(10,0,1,'Computer software',0),(11,1,2,'Insurance components',0),(12,1,2,'Semiconductor materials',0),(13,1,2,'Other electronic materials',0),(14,1,2,'Capacitors',0),(15,1,2,'Electronic Components',0);
/*!40000 ALTER TABLE `productcategories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productprices`
--

DROP TABLE IF EXISTS `productprices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `productprices` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type_id` tinyint(1) NOT NULL DEFAULT '1',
  `product_id` int(10) NOT NULL DEFAULT '-1',
  `brand_id` smallint(6) NOT NULL DEFAULT '-1',
  `member_id` int(10) NOT NULL DEFAULT '-1',
  `company_id` int(10) NOT NULL DEFAULT '-1',
  `area_id` smallint(6) NOT NULL DEFAULT '0',
  `price_trends` tinyint(1) NOT NULL DEFAULT '0',
  `category_id` smallint(6) NOT NULL DEFAULT '0',
  `source` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `units` tinyint(1) NOT NULL DEFAULT '1',
  `currency` tinyint(1) NOT NULL DEFAULT '1',
  `price` float(9,2) NOT NULL DEFAULT '0.00',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productprices`
--

LOCK TABLES `productprices` WRITE;
/*!40000 ALTER TABLE `productprices` DISABLE KEYS */;
/*!40000 ALTER TABLE `productprices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `member_id` int(10) NOT NULL DEFAULT '0',
  `company_id` int(10) NOT NULL DEFAULT '0',
  `cache_companyname` varchar(100) NOT NULL DEFAULT '',
  `sort_id` tinyint(1) NOT NULL DEFAULT '1',
  `brand_id` smallint(6) NOT NULL DEFAULT '0',
  `category_id` smallint(6) NOT NULL DEFAULT '0',
  `industry_id` smallint(6) NOT NULL DEFAULT '0',
  `country_id` smallint(6) NOT NULL DEFAULT '0',
  `area_id` smallint(6) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `price` float(9,2) NOT NULL DEFAULT '0.00',
  `sn` varchar(20) NOT NULL DEFAULT '',
  `spec` varchar(20) NOT NULL DEFAULT '',
  `produce_area` varchar(50) NOT NULL DEFAULT '',
  `packing_content` varchar(100) NOT NULL DEFAULT '',
  `picture` varchar(50) NOT NULL DEFAULT '',
  `content` text,
  `producttype_id` smallint(6) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '1',
  `ifnew` tinyint(1) NOT NULL DEFAULT '0',
  `ifcommend` tinyint(1) NOT NULL DEFAULT '0',
  `priority` tinyint(1) NOT NULL DEFAULT '0',
  `tag_ids` varchar(255) DEFAULT '',
  `clicked` smallint(6) NOT NULL DEFAULT '1',
  `formattribute_ids` text,
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `picture` (`picture`,`status`,`state`),
  KEY `picture_2` (`picture`,`status`,`state`),
  KEY `picture_3` (`picture`,`status`,`state`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,1,1,'Ualink E-Commerce',0,0,0,5,0,1,'Rubber grommet',100.00,'','','','','sample/product/1.jpg','Feature This is kind of rubber grommet to use industrial and automotive field. Material : EPDM, NBR, Silicone, CR',1,1,1,0,1,0,'',10,NULL,1313811282,1313811282),(2,1,1,'Ualink E-Commerce',1,0,0,1,0,1,'Plastics parts',125.00,'','','','','sample/product/2.jpg','Feature This is kind of plastics parts to use industrial and automotive parts. Material : Nylon, PET, PPS',1,1,1,0,1,0,NULL,2,NULL,1313811282,1313811282),(3,1,1,'Ualink E-Commerce',1,0,0,1,0,1,'Interlocking Rubber Flooring',256.00,'','','','','sample/product/3.jpg','Product Description Interlocking tiles simply lock together for a quick and easy installation.',1,1,1,0,1,0,NULL,11,NULL,1313811282,1313811282),(4,1,1,'Ualink E-Commerce',1,0,0,1,0,1,'Sweep Movement',352.00,'','','','','sample/product/4.jpg','Product Name: Sweep Movement Size: 56x56x16. 2mm Weight: 22g Crystal Frequency: 32, 768KHz Accuracy: (A)+/- 0. 5',1,1,1,0,0,0,NULL,2,NULL,1313811282,1313811282),(5,1,1,'Ualink E-Commerce',1,0,0,1,0,1,'ASA Pocket Bike 206A with CE',145.00,'','','','','sample/product/5.jpg','206A Transmission chain Engine Type 49cc/47cc/40cc air cooling Starting Mode drawing rope Fuel Tank 0.81L Max.',2,1,1,0,0,0,NULL,2,NULL,1313811282,1313811282),(6,1,1,'Ualink E-Commerce',1,0,0,1,0,1,'Brand Sunglasses,Sunglass.Paypal Verified Member',255.00,'','','','','sample/product/6.jpg','We accept paypal, we are verified paypal member in US. We have agent located in USA to do after-sale service.',2,1,1,0,0,0,NULL,4,NULL,1313811282,1313811282),(7,1,1,'Ualink E-Commerce',1,0,0,1,0,1,'Double Sided Acrylic Foam Tape',6632.00,'','','','','sample/product/7.jpg','Description 1) Characteristic of Acrylic Foam Tape - Possible to strong bonding to adhere with some pressure. ',3,1,1,0,0,0,NULL,8,NULL,1313811282,1313811282);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productsorts`
--

DROP TABLE IF EXISTS `productsorts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `productsorts` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `display_order` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productsorts`
--

LOCK TABLES `productsorts` WRITE;
/*!40000 ALTER TABLE `productsorts` DISABLE KEYS */;
INSERT INTO `productsorts` VALUES (1,'Newest Product',0),(2,'Stored Product',0),(3,'Common Product',0);
/*!40000 ALTER TABLE `productsorts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `producttypes`
--

DROP TABLE IF EXISTS `producttypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `producttypes` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `member_id` int(10) NOT NULL DEFAULT '0',
  `company_id` int(10) NOT NULL DEFAULT '0',
  `name` varchar(25) NOT NULL DEFAULT '',
  `level` tinyint(1) NOT NULL DEFAULT '0',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `producttypes`
--

LOCK TABLES `producttypes` WRITE;
/*!40000 ALTER TABLE `producttypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `producttypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotes`
--

DROP TABLE IF EXISTS `quotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quotes` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `product_id` int(10) NOT NULL DEFAULT '-1',
  `market_id` smallint(6) NOT NULL DEFAULT '-1',
  `type_id` smallint(6) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `area_id` smallint(6) NOT NULL DEFAULT '0',
  `area_id1` smallint(6) NOT NULL DEFAULT '0',
  `area_id2` smallint(6) NOT NULL DEFAULT '0',
  `area_id3` smallint(6) NOT NULL DEFAULT '0',
  `max_price` float(9,2) NOT NULL DEFAULT '0.00',
  `min_price` float(9,2) NOT NULL DEFAULT '0.00',
  `units` tinyint(1) NOT NULL DEFAULT '1',
  `currency` tinyint(1) NOT NULL DEFAULT '1',
  `trend_data` text NOT NULL,
  `hits` int(10) NOT NULL DEFAULT '1',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotes`
--

LOCK TABLES `quotes` WRITE;
/*!40000 ALTER TABLE `quotes` DISABLE KEYS */;
INSERT INTO `quotes` VALUES (1,1,-1,0,'Today, the International Cotton Indices(SM)','',0,0,0,0,100.00,90.00,1,1,'',4,1313811282,0),(2,1,-1,0,'A national cotton prices index A today','',0,0,0,0,150.00,100.00,1,1,'',1,1313811282,0),(3,1,-1,0,'A national cotton prices index B today','',0,0,0,0,210.00,120.00,1,1,'',1,1313811282,0),(4,1,-1,0,'Chinese cotton purchase price index today','',0,0,0,0,230.00,200.00,1,1,'',4,1313811282,0),(10,-1,-1,0,'Today, parts of the Market Price of soybean meal price','',0,0,0,0,0.00,0.00,1,1,'a:2:{s:1:\"x\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:1:\"y\";a:2:{i:0;s:3:\"150\";i:1;s:3:\"200\";}}',24,1313811282,1313811282);
/*!40000 ALTER TABLE `quotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotetypes`
--

DROP TABLE IF EXISTS `quotetypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quotetypes` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `parent_id` smallint(6) NOT NULL DEFAULT '0',
  `level` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(255) NOT NULL DEFAULT '',
  `display_order` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotetypes`
--

LOCK TABLES `quotetypes` WRITE;
/*!40000 ALTER TABLE `quotetypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `quotetypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roleadminers`
--

DROP TABLE IF EXISTS `roleadminers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roleadminers` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `adminrole_id` int(2) DEFAULT NULL,
  `adminer_id` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roleadminers`
--

LOCK TABLES `roleadminers` WRITE;
/*!40000 ALTER TABLE `roleadminers` DISABLE KEYS */;
/*!40000 ALTER TABLE `roleadminers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roleprivileges`
--

DROP TABLE IF EXISTS `roleprivileges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roleprivileges` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `adminrole_id` int(2) DEFAULT NULL,
  `adminprivilege_id` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roleprivileges`
--

LOCK TABLES `roleprivileges` WRITE;
/*!40000 ALTER TABLE `roleprivileges` DISABLE KEYS */;
/*!40000 ALTER TABLE `roleprivileges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `services` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `member_id` int(10) NOT NULL DEFAULT '0',
  `title` varchar(25) NOT NULL DEFAULT '',
  `content` text,
  `nick_name` varchar(25) DEFAULT '',
  `email` varchar(25) NOT NULL DEFAULT '',
  `user_ip` varchar(11) NOT NULL DEFAULT '',
  `type_id` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  `revert_content` text,
  `revert_date` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `sesskey` char(32) NOT NULL DEFAULT '',
  `expiry` int(10) NOT NULL DEFAULT '0',
  `expireref` char(64) NOT NULL DEFAULT '',
  `data` text,
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  KEY `sess2_expiry` (`expiry`),
  KEY `sess2_expireref` (`expireref`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `type_id` tinyint(1) NOT NULL DEFAULT '0',
  `variable` varchar(150) NOT NULL DEFAULT '',
  `valued` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `variable` (`variable`)
) ENGINE=MyISAM AUTO_INCREMENT=412 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (406,0,'site_name','PHPB2B e-commerce Web Site Management System industry'),(407,0,'site_title','PHPB2B electronic commerce network industries - Powered By PHPB2B'),(350,0,'site_banner_word','The Professional B2B Online'),(4,0,'company_name','Copyright'),(409,0,'site_url','http://192.168.1.13/b2b/'),(353,0,'icp_number','ICP Num.'),(7,0,'service_tel','(86)10-41235678'),(8,0,'sale_tel','(86)10-41235678'),(9,0,'service_qq','1319250566'),(10,0,'service_msn','service@host.com'),(11,0,'service_email','service@host.com'),(324,0,'site_description','<p>phpb2b description</p>'),(13,0,'cp_picture','0'),(14,0,'register_picture','0'),(15,0,'login_picture','0'),(16,0,'vispost_auth','1'),(17,0,'watermark','1'),(410,0,'watertext','http://192.168.1.13/b2b/'),(19,0,'watercolor','#990000'),(20,0,'add_market_check','1'),(21,0,'regcheck','0'),(268,0,'vis_post','1'),(270,0,'vis_post_check','0'),(271,0,'sell_logincheck','1'),(272,0,'buy_logincheck','0'),(405,0,'install_dateline','1313811281'),(27,0,'last_backup','1313811282'),(28,0,'smtp_server','smtp.yourdomain.com'),(29,0,'smtp_port','25'),(30,0,'smtp_auth','1'),(31,0,'mail_from','administrator@host.com'),(32,0,'mail_fromwho','Administrator'),(33,0,'auth_username','administrator@host.com'),(34,0,'auth_password','password'),(35,0,'send_mail','2'),(36,0,'sendmail_silent','1'),(37,0,'mail_delimiter','0'),(360,0,'reg_filename','register.php'),(402,0,'new_userauth','0'),(361,0,'post_filename','post.php'),(41,0,'forbid_ip',''),(403,0,'ip_reg_sep','0'),(408,0,'backup_dir','twMYnS'),(258,0,'capt_logging','0'),(259,0,'capt_register','1'),(260,0,'capt_post_free','0'),(261,0,'capt_add_market','0'),(262,0,'capt_login_admin','1'),(263,0,'capt_apply_friendlink','0'),(264,0,'capt_service','0'),(51,0,'backup_type','1'),(400,0,'register_type','open_common_reg'),(411,0,'auth_key','tester'),(54,0,'keyword_bidding','0'),(201,0,'passport_support','0'),(351,0,'site_logo','images/logo.jpg'),(362,0,'main_cache','1'),(363,0,'member_cache','0'),(364,0,'space_cache','0'),(365,0,'label_cache','0'),(366,0,'main_cache_lifetime','3600'),(367,0,'main_cache_check','0'),(344,1,'update_alert_type','1'),(345,1,'update_alert_lasttime','1301549982'),(369,0,'theme','red'),(269,0,'tag_check','0'),(273,0,'session_savepath','0'),(274,1,'offer_expire_method','1'),(275,1,'offer_moderate_point','0'),(276,1,'offer_refresh_lower_day','3'),(277,1,'offer_update_lower_hour','24'),(278,1,'offer_filter','0'),(358,0,'redirect_url',''),(399,0,'languages','en'),(346,0,'time_offset','0'),(347,0,'date_format','Y-m-d'),(401,0,'agreement','Demo'),(359,0,'space_name','Space'),(404,0,'welcome_msg','0');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spacecaches`
--

DROP TABLE IF EXISTS `spacecaches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spacecaches` (
  `cache_spacename` varchar(255) NOT NULL DEFAULT '',
  `company_id` int(10) NOT NULL DEFAULT '-1',
  `data1` text NOT NULL,
  `data2` text NOT NULL,
  `expiration` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`company_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spacecaches`
--

LOCK TABLES `spacecaches` WRITE;
/*!40000 ALTER TABLE `spacecaches` DISABLE KEYS */;
/*!40000 ALTER TABLE `spacecaches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spacelinks`
--

DROP TABLE IF EXISTS `spacelinks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spacelinks` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `member_id` int(10) NOT NULL DEFAULT '0',
  `company_id` int(10) NOT NULL DEFAULT '0',
  `display_order` smallint(3) NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `is_outlink` tinyint(1) NOT NULL DEFAULT '0',
  `description` varchar(100) NOT NULL DEFAULT '',
  `logo` varchar(255) NOT NULL DEFAULT '',
  `highlight` tinyint(1) NOT NULL DEFAULT '0',
  `created` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spacelinks`
--

LOCK TABLES `spacelinks` WRITE;
/*!40000 ALTER TABLE `spacelinks` DISABLE KEYS */;
/*!40000 ALTER TABLE `spacelinks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spreads`
--

DROP TABLE IF EXISTS `spreads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spreads` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `member_id` int(10) NOT NULL DEFAULT '-1',
  `keyword_name` varchar(25) NOT NULL DEFAULT '',
  `title` varchar(50) NOT NULL DEFAULT '',
  `content` varchar(200) NOT NULL DEFAULT '',
  `target_url` varchar(100) NOT NULL DEFAULT '',
  `hits` int(10) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `expiration` int(10) NOT NULL DEFAULT '0',
  `display_order` tinyint(1) NOT NULL DEFAULT '0',
  `created` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `spread` (`id`,`keyword_name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spreads`
--

LOCK TABLES `spreads` WRITE;
/*!40000 ALTER TABLE `spreads` DISABLE KEYS */;
INSERT INTO `spreads` VALUES (1,1,'Inc','Beijing Ualink E-Commerce Inc.','Although solid Sino-US economic and trade relations do not automatically mean good political ties, they serve as a buffer to serious clashes between the two countries','http://www.phpb2b.com',1,1,1316403282,0,1313811282);
/*!40000 ALTER TABLE `spreads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `standards`
--

DROP TABLE IF EXISTS `standards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `standards` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `attachment_id` smallint(6) NOT NULL DEFAULT '0',
  `type_id` smallint(6) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `source` varchar(255) NOT NULL DEFAULT '',
  `digest` varchar(255) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `publish_time` int(10) NOT NULL DEFAULT '0',
  `force_time` int(10) NOT NULL DEFAULT '0',
  `clicked` smallint(6) NOT NULL DEFAULT '1',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `standards`
--

LOCK TABLES `standards` WRITE;
/*!40000 ALTER TABLE `standards` DISABLE KEYS */;
INSERT INTO `standards` VALUES (7,0,2,'Help revolutionaries get rid of Gadafi.','','','',0,0,1,1313811282,0);
/*!40000 ALTER TABLE `standards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `standardtypes`
--

DROP TABLE IF EXISTS `standardtypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `standardtypes` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `display_order` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `standardtypes`
--

LOCK TABLES `standardtypes` WRITE;
/*!40000 ALTER TABLE `standardtypes` DISABLE KEYS */;
INSERT INTO `standardtypes` VALUES (1,'Administrative regulations',0),(2,'Safety Standards',0);
/*!40000 ALTER TABLE `standardtypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `member_id` int(10) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `numbers` smallint(6) NOT NULL DEFAULT '0',
  `closed` tinyint(1) NOT NULL DEFAULT '0',
  `flag` tinyint(1) NOT NULL DEFAULT '0',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `title` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
INSERT INTO `tags` VALUES (1,0,'Hots',1,0,0,1313811282,1313811282),(2,0,'Search',2,0,1,1313811282,1313811282),(3,0,'Label',1,0,2,1313811282,1313811282);
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `templets`
--

DROP TABLE IF EXISTS `templets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templets` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL DEFAULT '',
  `title` varchar(25) NOT NULL DEFAULT '',
  `directory` varchar(100) NOT NULL DEFAULT '',
  `type` enum('system','user') NOT NULL DEFAULT 'system',
  `author` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `require_membertype` varchar(100) NOT NULL DEFAULT '0',
  `require_membergroups` varchar(100) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `templets`
--

LOCK TABLES `templets` WRITE;
/*!40000 ALTER TABLE `templets` DISABLE KEYS */;
INSERT INTO `templets` VALUES (3,'brown','Brown Space Skin','skins/brown/','user','PB TEAM','','A PHPB2B Corperate Templet. Enjoy!',0,'0','0',1),(4,'red','Red Space Skin','skins/red/','user','PB TEAM','','A PHPB2B Corperate Templet. Enjoy!',0,'0','0',1),(5,'default','Default Space Skin','skins/default/','user','PB TEAM','','A PHPB2B Corperate Templet. Enjoy!',0,'0','0',1),(7,'green','Green Space Skin','skins/green/','user','PB TEAM','','A PHPB2B Corperate Templet. Enjoy!',0,'0','0',1),(8,'orange','Orange Space Skin','skins/orange/','user','PB TEAM','','A PHPB2B Corperate Templet. Enjoy!',0,'0','0',1),(15,'green','Green Site Templet','templates/green/','system','PB TEAM','#71B522','A PHPB2B Orange Color Style Templet. Enjoy!',0,'0','0',1),(11,'red','Red Site Templet','templates/red/','system','PB TEAM','#CF352E','A PHPB2B Red Color Style Templet. Enjoy!',1,'0','0',1),(12,'default','Default Site Templet','templates/default/','system','PB TEAM','#4DB5F8','A Ualink Default Template. Enjoy!',0,'0','0',1);
/*!40000 ALTER TABLE `templets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topicnews`
--

DROP TABLE IF EXISTS `topicnews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topicnews` (
  `topic_id` smallint(6) NOT NULL DEFAULT '0',
  `news_id` smallint(6) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topicnews`
--

LOCK TABLES `topicnews` WRITE;
/*!40000 ALTER TABLE `topicnews` DISABLE KEYS */;
/*!40000 ALTER TABLE `topicnews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topics`
--

DROP TABLE IF EXISTS `topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topics` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `alias_name` varchar(100) NOT NULL DEFAULT '',
  `templet` varchar(100) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `picture` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topics`
--

LOCK TABLES `topics` WRITE;
/*!40000 ALTER TABLE `topics` DISABLE KEYS */;
INSERT INTO `topics` VALUES (1,'test1','test1','BRIC countries, the third meeting between the leaders','sample/topic/1.jpg','',1313811282,0),(2,'test2','','Ipad2 Released','sample/topic/2.jpg','',1313811282,0),(3,'test3','','9.0 earthquake near the Sea of Japan','sample/topic/3.jpg','',1313811282,0);
/*!40000 ALTER TABLE `topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tradefields`
--

DROP TABLE IF EXISTS `tradefields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tradefields` (
  `trade_id` int(10) NOT NULL DEFAULT '0',
  `member_id` int(10) NOT NULL DEFAULT '0',
  `link_man` varchar(100) NOT NULL DEFAULT '',
  `address` varchar(100) NOT NULL DEFAULT '',
  `company_name` varchar(100) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `prim_tel` tinyint(1) NOT NULL DEFAULT '0',
  `prim_telnumber` varchar(25) NOT NULL DEFAULT '',
  `prim_im` tinyint(1) NOT NULL DEFAULT '0',
  `prim_imaccount` varchar(100) NOT NULL DEFAULT '',
  `brand_name` char(50) NOT NULL DEFAULT '',
  `template` char(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`trade_id`),
  UNIQUE KEY `trade_id` (`trade_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tradefields`
--

LOCK TABLES `tradefields` WRITE;
/*!40000 ALTER TABLE `tradefields` DISABLE KEYS */;
/*!40000 ALTER TABLE `tradefields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type_id` tinyint(2) NOT NULL DEFAULT '0',
  `industry_id` smallint(6) NOT NULL DEFAULT '0',
  `country_id` smallint(6) NOT NULL DEFAULT '0',
  `area_id` smallint(6) NOT NULL DEFAULT '0',
  `member_id` int(10) NOT NULL DEFAULT '0',
  `company_id` int(5) NOT NULL DEFAULT '0',
  `cache_username` varchar(25) NOT NULL DEFAULT '',
  `cache_companyname` varchar(100) NOT NULL DEFAULT '',
  `cache_contacts` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(100) NOT NULL DEFAULT '',
  `adwords` varchar(25) NOT NULL DEFAULT '',
  `content` text,
  `price` float(9,2) NOT NULL DEFAULT '0.00',
  `measuring_unit` varchar(15) NOT NULL DEFAULT '0',
  `monetary_unit` varchar(15) NOT NULL DEFAULT '0',
  `packing` varchar(150) NOT NULL DEFAULT '',
  `quantity` varchar(25) NOT NULL DEFAULT '',
  `display_order` tinyint(1) NOT NULL DEFAULT '0',
  `display_expiration` int(10) NOT NULL DEFAULT '0',
  `spec` varchar(200) NOT NULL DEFAULT '',
  `sn` varchar(25) NOT NULL DEFAULT '',
  `picture` varchar(50) NOT NULL DEFAULT '',
  `picture_remote` varchar(50) NOT NULL DEFAULT '',
  `status` tinyint(2) NOT NULL DEFAULT '0',
  `submit_time` int(10) NOT NULL DEFAULT '0',
  `expire_time` int(10) NOT NULL DEFAULT '0',
  `expire_days` int(3) NOT NULL DEFAULT '10',
  `if_commend` tinyint(1) NOT NULL DEFAULT '0',
  `if_urgent` enum('0','1') NOT NULL DEFAULT '0',
  `if_locked` enum('0','1') NOT NULL DEFAULT '0',
  `require_point` smallint(6) NOT NULL DEFAULT '0',
  `require_membertype` smallint(6) NOT NULL DEFAULT '0',
  `require_freedate` int(10) NOT NULL DEFAULT '0',
  `ip_addr` varchar(15) NOT NULL DEFAULT '',
  `clicked` int(10) NOT NULL DEFAULT '1',
  `tag_ids` varchar(255) NOT NULL DEFAULT '',
  `formattribute_ids` text,
  `highlight` tinyint(2) NOT NULL DEFAULT '0',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `type_id` (`type_id`,`picture`,`status`,`expire_time`),
  KEY `type_id_2` (`type_id`,`picture`,`status`,`expire_time`),
  KEY `type_id_3` (`type_id`,`status`),
  KEY `type_id_4` (`type_id`,`status`,`expire_time`),
  KEY `type_id_5` (`type_id`,`picture`,`status`,`expire_time`)
) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES (1,1,1,0,0,1,13,'','','','Buy Wood Sawing Machines ','Mark Board','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/1.jpg','',1,1293936472,1294022872,10,1,'1','0',0,0,0,'',4,'',NULL,0,1313811282,1313811282),(2,1,1,0,0,1,13,'','','','Buy Office Stationery','cork block','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/2.jpg','',1,1293936472,1294022872,10,1,'1','0',0,0,0,'',3,'',NULL,0,1313811282,1313811282),(3,1,1,0,0,1,13,'','','','Buy looking for gas motor bicycle kits electric bicycle kits','cork roll','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/3.jpg','',1,1293936472,1294022872,10,1,'1','0',0,0,0,'',1,'',NULL,0,1313811282,1313811282),(4,1,1,0,0,1,13,'','','','Buy Apple Products','cork sheet','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/4.jpg','',1,1293936472,1294022872,10,1,'1','0',0,0,0,'',3,'',NULL,0,1313811282,1313811282),(5,1,1,0,0,1,13,'','','','Buy Used Steam Locomotive','600 ring','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/5.jpg','',1,1293936472,1294022872,10,1,'1','0',0,0,0,'',1,'',NULL,0,1313811282,1313811282),(6,1,1,0,0,1,13,'','','','Buy Pig Iron','600/601 pipe','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/6.jpg','',1,1293936472,1294022872,10,1,'1','0',0,0,0,'',3,'',NULL,0,1313811282,1313811282),(7,1,1,0,0,1,13,'','','','Buy Agent Required for Complete Sourcing Project','BP connectors ','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/7.jpg','',1,1293936472,1294022872,10,1,'1','0',0,0,0,'',2,'',NULL,0,1313811282,1313811282),(8,1,1,0,0,1,1,'','','','Buy Plastic Scrap','circular connectors','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/8.jpg','',1,1293936472,1294022872,10,1,'1','0',0,0,0,'',1,'',NULL,0,1313811282,1313811282),(9,1,1,0,0,1,1,'','','','Buy Scrap','ODU connectors','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/9.jpg','',1,1293936472,1294022872,10,1,'1','0',0,0,0,'',2,'',NULL,0,1313811282,1313811282),(10,1,1,0,0,1,1,'','','','Buy Looking for,Water Dispenser,Heater and LCD TV.','LEMO connectors','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/10.jpg','',1,1293936472,1294022872,10,1,'1','0',0,0,0,'',5,'',NULL,0,1313811282,1313811282),(11,1,1,0,0,1,1,'','','','Buy Iron Ore','ATS','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/11.jpg','',1,1293936472,1294022872,10,1,'0','0',0,0,0,'',3,'',NULL,0,1313811282,1313811282),(12,1,1,0,0,1,1,'','','','Buy Children Football Boot','Paralleling panel','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/12.jpg','',1,1294062132,1294062132,10,1,'0','0',0,0,0,'',3,'',NULL,0,1313811282,1313811282),(13,1,1,0,0,1,1,'','','','Sell Construction machinery engine','Mobile gen-set','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/13.jpg','',1,1294062132,1294062132,10,1,'0','0',0,0,0,'',4,'',NULL,0,1313811282,1313811282),(14,1,1,0,0,1,1,'','','','Sell Brazilian Frozen Meat','MARKING MACHINE','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/14.jpg','',1,1301194546,1302058546,10,1,'0','0',0,0,0,'',1,'',NULL,0,1313811282,1313811282),(15,2,1,0,0,1,1,'','','','Sell YC (YELLOW CORN/MAIZE)','GPS','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/1.jpg','',1,1294062132,1294062132,10,1,'0','0',0,0,0,'',1,'',NULL,0,1313811282,1313811282),(16,2,1,0,0,1,1,'','','','Sell Chicken and Chicken Parts','MP4 device','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/2.jpg','',1,1294062132,1294062132,10,1,'0','0',0,0,0,'',1,'',NULL,0,1313811282,1313811282),(17,2,1,0,0,1,1,'','','','Sell Roasted Coffee','spotlight','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/3.jpg','',1,1294062132,1294062132,10,1,'0','0',0,0,0,'',2,'',NULL,0,1313811282,1313811282),(18,2,1,0,0,1,13,'','','','Sell Cappuccino','Neon Tube','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/4.jpg','',1,1294062132,1294062132,10,1,'0','0',0,0,0,'',1,'',NULL,0,1313811282,1313811282),(19,2,1,0,0,1,1,'','','','Sell Brazilian Green Coffee','Warning Lihgt','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/5.jpg','',1,1303736195,1303736195,10,1,'0','0',0,0,0,'',2,'',NULL,0,1313811282,1313811282),(20,2,1,0,0,1,1,'','','','Sell Brazilian and Indian Instant Coffee','fall lighting','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/6.jpg','',1,1303736195,1303736195,10,1,'0','0',0,0,0,'',1,'',NULL,0,1313811282,1313811282),(21,2,1,0,0,1,1,'','','','Sell Brazilian and Indian Agglomerated Instant Coffee','Candle Light','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/7.jpg','',1,1303736195,1303736195,10,1,'0','0',0,0,0,'',2,'',NULL,0,1313811282,1313811282),(22,2,1,0,0,1,1,'','','','Sell Brazilian and Indian Spray Dried ( Powder ) Instant Coffee','lighting','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/8.jpg','',1,1303736195,1303736195,10,1,'0','0',0,0,0,'',3,'',NULL,0,1313811282,1313811282),(23,2,1,0,0,1,1,'','','','Promotional Wooden Comb ','rain light','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/9.jpg','',1,1303736195,1303736195,10,1,'0','0',0,0,0,'',1,'',NULL,0,1313811282,1313811282),(24,2,1,0,0,1,1,'','','','Sell Aida Arm Chairs ','Neon Tube','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/10.jpg','',1,1303736195,1303736195,10,1,'0','0',0,0,0,'',2,'',NULL,0,1313811282,1313811282),(25,2,2,0,0,1,1,'','','','Vacuum Dehydrator For Emulsified','curvang machine','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/11.jpg','',1,1303736195,1303736195,10,1,'0','0',0,0,0,'',2,'',NULL,0,1313811282,1313811282),(26,2,2,0,0,1,1,'','','','Samsung Cartridge Chips ','Bag Hanger','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/12.jpg','',1,1303736195,1303736195,10,1,'0','0',0,0,0,'',2,'',NULL,0,1313811282,1313811282),(27,2,2,3,0,1,1,'','','','Sell Polarized Lens','Key Chain','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/13.jpg','',1,1303736195,1303736195,10,1,'0','0',0,0,0,'',1,'',NULL,0,1313811282,1313811282),(28,2,2,3,0,1,1,'','','','Buy Cattle Fence From','gasoline generator','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/14.jpg','',1,1303736346,1304600346,10,1,'0','0',0,0,0,'',7,'',NULL,0,1313811282,1313811282),(29,6,1,1,3,1,1,'','','','Sell JY-8830 Rechargeable Flashlight','Rechargeable Flashlight ','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/1.jpg','',1,1303736346,1304600346,10,1,'0','0',0,0,0,'',9,'3,4','5,6,7,8,9,10',0,1313811282,1313811282),(70,4,3,2,1,1,1,'','','','Sell JY-5530 Rechargeable Multi-purpose Fan','','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/12.jpg','',0,1303736168,1303736168,10,0,'0','0',0,0,0,'',1,'',NULL,0,1313811282,1313811282),(71,4,3,2,1,1,1,'','','','Sell automatic block making machine','','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/13.jpg','',0,1303736168,1303736168,10,0,'0','0',0,0,0,'',1,'',NULL,0,1313811282,1313811282),(30,6,1,1,3,1,1,'','','','Sell cement mixer','cement mixer','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/2.jpg','',1,1303736346,1304600346,10,1,'0','0',0,0,0,'',2,'',NULL,0,1313811282,1313811282),(31,6,1,1,3,1,1,'','','','Sell bread packing machine','packing machine','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/3.jpg','',1,1303736346,1304600346,10,1,'0','0',0,0,0,'',1,'',NULL,51,1313811282,1313811282),(32,6,1,1,3,1,1,'','','','Sell oil filter','oil filter','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/4.jpg','',1,1303736346,1304600346,10,1,'0','0',0,0,0,'',2,'',NULL,0,1313811282,1313811282),(33,6,2,1,3,1,1,'','','','Offer Expanded Graphite Gaskets','Graphite Gaskets','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/5.jpg','',1,1303736346,1304600346,10,1,'0','0',0,0,0,'',1,'',NULL,46,1313811282,1313811282),(34,6,2,1,2,1,1,'','','','Offer Oval Ring Joint Gasket','Joint Gasket','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/6.jpg','',1,1303736346,1304600346,10,1,'0','0',0,0,0,'',1,'',NULL,0,1313811282,1313811282),(35,6,2,1,2,1,1,'','','','Offer Corrugated Gaskets','Corrugated Gaskets','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/7.jpg','',1,1303736346,1304600346,10,1,'0','0',0,0,0,'',2,'',NULL,0,1313811282,1313811282),(36,6,2,1,2,1,1,'','','','Offer Copper Gaskets','Copper Gaskets','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/8.jpg','',1,1303736346,1304600346,10,1,'0','0',0,0,0,'',1,'',NULL,0,1313811282,1313811282),(37,6,3,1,2,1,1,'','','','Offer Spiral Wound Gaskets','Wound Gaskets','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/9.jpg','',1,0,0,10,1,'0','0',0,0,0,'',2,'',NULL,0,1313811282,1313811282),(38,6,3,1,1,1,1,'','','','Offer Rubber Gaskets','Rubber Gaskets','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/10.jpg','',1,0,0,10,1,'0','0',0,0,0,'',1,'',NULL,47,1313811282,1313811282),(39,6,3,1,1,1,1,'','','','Sell rhinestone','rhinestone','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/11.jpg','',1,0,0,10,1,'0','0',0,0,0,'',1,'',NULL,0,1313811282,1313811282),(40,6,3,1,1,1,1,'','','','glass hotfix rhinestone','hotfix rhinestone','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/12.jpg','',1,0,0,10,1,'0','0',0,0,0,'',1,'',NULL,47,1313811282,1313811282),(41,6,3,1,1,1,1,'','','','Offers of Fishing Tackles','Fishing Tackles','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/1/13.jpg','',1,0,0,10,1,'0','0',0,0,0,'',5,'',NULL,47,1313811282,1313811282),(42,4,1,1,3,1,1,'','','','the Kite pole','','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/1.jpg','',1,0,0,10,1,'0','0',0,0,0,'',2,'',NULL,0,1313811282,1313811282),(43,4,1,1,3,1,1,'','','','the ski and walking pole ','','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/2.jpg','',1,0,0,10,1,'0','0',0,0,0,'',1,'',NULL,0,1313811282,1313811282),(44,4,1,1,3,1,1,'','','','Olive Stick ','','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/3.jpg','',1,0,0,10,1,'0','0',0,0,0,'',1,'',NULL,0,1313811282,1313811282),(45,4,1,1,3,1,1,'','','','MELAMINE MOLDING POWDER','','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/4.jpg','',1,0,0,10,1,'0','0',0,0,0,'',1,'',NULL,0,1313811282,1313811282),(46,4,2,1,2,1,1,'','','','glass rhinestones','','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/5.jpg','',1,1303736168,1303736168,10,1,'0','0',0,0,0,'',3,'',NULL,0,1313811282,1313811282),(47,4,2,1,2,1,1,'','','','CRYSTAL HOTFIX RHINESTONE','','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/6.jpg','',1,1303736168,1303736168,10,1,'0','0',0,0,0,'',6,'',NULL,47,1313811282,1313811282),(48,4,2,1,2,1,1,'','','','Corner Guard','','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/7.jpg','',1,1303736168,1303736168,10,1,'0','0',0,0,0,'',5,'',NULL,6,1313811282,1313811282),(49,4,2,1,2,1,1,'','','','Wall Guard','','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/8.jpg','',1,1303736168,1303736168,10,1,'0','0',0,0,0,'',4,'',NULL,0,1313811282,1313811282),(50,4,3,2,1,1,1,'','','','Hospital Handrail,Handrails','','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/9.jpg','',1,1303736168,1303736168,10,1,'0','0',0,0,0,'',5,'',NULL,51,1313811282,1313811282),(68,4,3,2,1,1,1,'','','','Brazilian Soft Drinks','','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/10.jpg','',0,1303736168,1303736168,10,0,'0','0',0,0,0,'',1,'',NULL,0,1313811282,1313811282),(69,4,3,2,1,1,1,'','','','Sell Brazilian Fruit Juice','','This is the demo data, does not guarantee the authenticity of the data',1.23,'0','0','','',0,0,'','','sample/offer/2/11.jpg','',0,1303736168,1303736168,10,0,'0','0',0,0,0,'',1,'',NULL,0,1313811282,1313811282);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tradetypes`
--

DROP TABLE IF EXISTS `tradetypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tradetypes` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `parent_id` smallint(3) NOT NULL DEFAULT '0',
  `name` varchar(25) NOT NULL DEFAULT '',
  `level` tinyint(1) NOT NULL DEFAULT '1',
  `display_order` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tradetypes`
--

LOCK TABLES `tradetypes` WRITE;
/*!40000 ALTER TABLE `tradetypes` DISABLE KEYS */;
INSERT INTO `tradetypes` VALUES (1,0,'Buy',1,0),(2,0,'Sell',1,0),(3,0,'Agent',1,0),(4,3,'Ship',1,0),(5,0,'Commercial',1,0),(6,5,'Invest',1,0),(7,0,'Store',1,0),(8,7,'Stock',1,0),(9,1,'Internal',2,0),(10,1,'External',2,0),(11,7,'Wholesale',2,0),(12,3,'Agent',2,0),(13,5,'Investment ',2,0);
/*!40000 ALTER TABLE `tradetypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trustlogs`
--

DROP TABLE IF EXISTS `trustlogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trustlogs` (
  `member_id` int(10) NOT NULL AUTO_INCREMENT,
  `trusttype_id` smallint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`member_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trustlogs`
--

LOCK TABLES `trustlogs` WRITE;
/*!40000 ALTER TABLE `trustlogs` DISABLE KEYS */;
/*!40000 ALTER TABLE `trustlogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trusttypes`
--

DROP TABLE IF EXISTS `trusttypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trusttypes` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '',
  `description` text,
  `image` varchar(255) NOT NULL DEFAULT '',
  `display_order` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trusttypes`
--

LOCK TABLES `trusttypes` WRITE;
/*!40000 ALTER TABLE `trusttypes` DISABLE KEYS */;
INSERT INTO `trusttypes` VALUES (2,'Company',NULL,'company.gif',0,1),(1,'ID',NULL,'truename.gif',0,1);
/*!40000 ALTER TABLE `trusttypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `typemodels`
--

DROP TABLE IF EXISTS `typemodels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `typemodels` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL DEFAULT '',
  `type_name` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `typemodels`
--

LOCK TABLES `typemodels` WRITE;
/*!40000 ALTER TABLE `typemodels` DISABLE KEYS */;
INSERT INTO `typemodels` VALUES (1,'expiration time','offer_expire'),(2,'Type','manage_type'),(3,'major markets','main_market'),(4,'registered capital','reg_fund'),(5,'turnover','year_annual'),(6,'economy type','economic_type'),(7,'moderation status','check_status'),(8,'employees','employee_amount'),(9,'status','common_status'),(10,'the proposed type','service_type'),(11,'educational experience','education'),(12,'wages','salary'),(13,'the nature','work_type'),(14,'Job Title','position'),(15,'gender','gender'),(16,'Phone Type','phone_type'),(17,'instant messaging category','im_type'),(18,'option','common_option'),(19,'honorific','calls'),(20,'units','measuring'),(21,'currency','monetary'),(22,'quote type','price_type'),(23,'price trend','price_trends');
/*!40000 ALTER TABLE `typemodels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `typeoptions`
--

DROP TABLE IF EXISTS `typeoptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `typeoptions` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `typemodel_id` smallint(3) NOT NULL DEFAULT '0',
  `option_value` varchar(50) NOT NULL DEFAULT '',
  `option_label` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=131 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `typeoptions`
--

LOCK TABLES `typeoptions` WRITE;
/*!40000 ALTER TABLE `typeoptions` DISABLE KEYS */;
INSERT INTO `typeoptions` VALUES (1,1,'10','10 days'),(2,1,'30','month'),(3,1,'90','three'),(4,1,'180','six'),(5,2,'1','production'),(6,2,'2','trade type'),(7,2,'3','service'),(8,2,'4','the Government or other agencies'),(9,3,'1','China'),(10,3,'2','Hong Kong, Macao and Taiwan'),(11,3,'3','North America'),(12,3,'4','South America'),(13,3,'5','Europe'),(14,3,'6','Asia'),(15,3,'7','Africa'),(16,3,'8','Oceania'),(17,3,'9','other market'),(18,4,'0','closed'),(19,4,'1','one hundred thousand yuan less'),(20,4,'2','RMB 10-30 million'),(21,4,'3','RMB 30-50 million'),(22,4,'4','RMB 50-100 million'),(23,4,'5','RMB 100-300 million'),(24,4,'6','RMB 300-500 million'),(25,4,'7','RMB 500-1,000 million'),(26,4,'8','million RMB 1000-5000'),(27,4,'9','more than RMB 50 million'),(28,4,'10','other'),(29,5,'1','RMB 10 million or less/year'),(30,5,'2','RMB 10-30 million/year'),(31,5,'3','RMB 30-50 million/year'),(32,5,'4','RMB 50-100 million/year'),(33,5,'5','RMB 100-300 million/year'),(34,5,'6','RMB 300-500 million/year'),(35,5,'7','RMB 500-1,000 million/year'),(36,5,'8','RMB 1000-5000 million/year'),(37,5,'9','more than 50 million RMB/year'),(38,5,'10','other'),(39,6,'1','state-owned enterprises'),(40,6,'2','collective enterprises'),(41,6,'3','Corporations'),(42,6,'4','joint venture'),(43,6,'5','limited liability company'),(44,6,'6','Corporation'),(45,6,'7','private'),(46,6,'8','individual enterprise'),(47,6,'9','non-profit organization'),(48,6,'10','other'),(49,7,'0','invalid'),(50,7,'1','effective'),(51,7,'2','awaiting approval'),(52,7,'3','audit is not passed'),(53,8,'1','5 less'),(54,8,'2','5-10 people'),(55,8,'3','11-50 people'),(56,8,'4','51-100 people'),(57,8,'5','101-500 persons'),(58,8,'6','501-1000 person'),(59,8,'7','1000 or more'),(60,10,'1','consultation'),(61,10,'2','proposal'),(62,10,'3','complaints'),(63,11,'0','other'),(64,11,'-1','not required'),(65,11,'-2','open'),(66,11,'1','Doctor'),(67,11,'2','Master'),(68,11,'3','undergraduate'),(69,11,'4','college'),(70,11,'5','secondary'),(71,11,'6','technical school'),(72,11,'7','high'),(73,11,'8','middle'),(74,11,'9','primary'),(75,12,'0','no choice'),(76,12,'-1','Interview'),(77,12,'1','1500 less'),(78,12,'2','1500-1999 RMB/month'),(79,12,'3','2000-2999 yuan/month'),(80,12,'4','3000-4999 yuan/month'),(81,12,'5','5000 above'),(82,13,'0','no choice'),(83,13,'1','full'),(84,13,'2','part-time'),(85,13,'3','provisional'),(86,13,'4','practice'),(87,13,'5','other'),(88,14,'0','no choice'),(89,14,'1','chairman, president and deputies'),(90,14,'2','the executive branch managers/executives'),(91,14,'3','technical manager/technical staff'),(92,14,'4','production manager/production staff'),(93,14,'5','marketing manager/marketing staff'),(94,14,'6,','purchasing department manager/procurement officer'),(95,14,'7','sales manager/sales'),(96,14,'8','other'),(97,15,'0','no choice'),(98,15,'1','Male'),(99,15,'2','Female'),(100,15,'-1','open'),(101,16,'1','mobile phone'),(102,16,'2','residential'),(103,16,'3','business phone'),(104,16,'4','other'),(105,17,'1','QQ'),(106,17,'2','ICQ'),(107,17,'3','MSN Messenger'),(108,17,'4','Yahoo Messenger'),(109,17,'5','Skype'),(110,17,'6','other'),(111,17,'0','no choice'),(112,16,'0','no choice'),(113,6,'0','no choice'),(114,9,'0','invalid'),(115,9,'1','effective'),(116,18,'0','no'),(117,18,'1','yes'),(118,19,'1','Mr.'),(119,19,'2','Ms.'),(120,20,'1','single'),(121,20,'2','pieces'),(122,21,'1','element'),(123,21,'3','USD'),(124,22,'1','buy'),(125,22,'2','sell'),(126,23,'1','up'),(127,23,'2','stable'),(128,23,'3','down'),(129,23,'4','uncertain'),(130,21,'2','million');
/*!40000 ALTER TABLE `typeoptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpages`
--

DROP TABLE IF EXISTS `userpages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpages` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `templet_name` varchar(50) NOT NULL DEFAULT '',
  `name` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(50) NOT NULL DEFAULT '',
  `digest` varchar(50) NOT NULL DEFAULT '',
  `content` text,
  `url` varchar(100) NOT NULL DEFAULT '',
  `display_order` tinyint(1) NOT NULL DEFAULT '0',
  `created` int(10) NOT NULL DEFAULT '0',
  `modified` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpages`
--

LOCK TABLES `userpages` WRITE;
/*!40000 ALTER TABLE `userpages` DISABLE KEYS */;
INSERT INTO `userpages` VALUES (1,'','aboutus','About Us','','','',0,1313811282,1313811282),(2,'','contactus','Contacts','','','',0,1313811282,1313811282),(4,'','sitemap','Sitemap','','','',0,1313811282,1313811282),(5,'','legal','Agreement','','','',0,1313811282,0),(6,'','friendlink','Links','','','friendlink.php',0,1313811282,0),(7,'','help','Helps','','','help/',0,1313811282,1313811282),(8,'','service','Service','','','',0,1313811282,1313811282),(9,'','special','Special','','','special/',0,1313811282,1313811282),(10,'','wap','WAP','Wap','','wap/index.php',0,1313811282,1313811282);
/*!40000 ALTER TABLE `userpages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visitlogs`
--

DROP TABLE IF EXISTS `visitlogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `visitlogs` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `salt` varchar(32) NOT NULL DEFAULT '',
  `date_line` varchar(15) NOT NULL DEFAULT '',
  `type_name` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `salt` (`salt`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visitlogs`
--

LOCK TABLES `visitlogs` WRITE;
/*!40000 ALTER TABLE `visitlogs` DISABLE KEYS */;
/*!40000 ALTER TABLE `visitlogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `words`
--

DROP TABLE IF EXISTS `words`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `words` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL DEFAULT '',
  `replace_to` varchar(50) NOT NULL DEFAULT '',
  `expiration` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `word` (`title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `words`
--

LOCK TABLES `words` WRITE;
/*!40000 ALTER TABLE `words` DISABLE KEYS */;
/*!40000 ALTER TABLE `words` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-09-05 12:05:15
